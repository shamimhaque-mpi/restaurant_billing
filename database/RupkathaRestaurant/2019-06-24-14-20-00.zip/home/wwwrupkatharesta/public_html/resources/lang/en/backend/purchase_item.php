<?php

return [
	'add_purchase_item' => 'Add Purchase Item',
	'purchase_item' => 'Purchase Item',
	'edit_purchase_item' => 'Edit Purchase Item',
	'purchase_item_list' => 'Purchase Item List',
	'add_purchase' => 'Add Purchase',
	'purchase_list' => 'Purchase List',
	'purchase_history' => 'Purchase History',
	'edit_purchase' => 'Edit Purchase',
	'history' => 'History',
];
