<?php

return [
	"name" => "নাম",
	"image" => "ফটো",
	"photo" => "ফটো",
	"title" => "টাইটেল",
	"status" => "অবস্থা",
	"select_category" => "ক্যাটাগরি নির্বাচন করুন",
	"select_subcategory" => "সাবক্যাটাগরি নির্বাচন করুন",
	"email" => "ইমেইল",
	"role" => "ভূমিকা",
	"select_role" => "ভূমিকা নির্বাচন করুন",
	"password" => "পাসওয়ার্ড",
	"username" => "ইউজারনেম",
	'select_product' => 'পণ্য নির্বাচন করুন',
];
