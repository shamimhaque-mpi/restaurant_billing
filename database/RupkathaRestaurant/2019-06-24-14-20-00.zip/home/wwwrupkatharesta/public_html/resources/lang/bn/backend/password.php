<?php

return [
	'new_password' => 'নতুন পাসওয়ার্ড',
	'old_password' => 'পুরাতন পাসওয়ার্ড ',
	'confirm_password' => 'কনফার্ম পাসওয়ার্ড',
];
