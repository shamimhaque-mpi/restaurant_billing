<?php

return[
	'access_information' => 'প্রবেশাধিকার তথ্য',
	'change_password' => 'পাসওয়ার্ড পরিবর্তন',
	'role_management' => 'মেনু ভূমিকা ব্যবস্থাপনা',
	'role' => 'মেনু ভূমিকা',
	'assign' => 'দায়িত্ব অর্পণ',
	'device' => 'ডিভাইস',
	'browser' => 'ব্রাউজার',
	'ip' => 'আইপি ঠিকানা',
	'log_activity' => 'লগ এক্টিভিটি',
	'admin_setting' => 'এডমিন সেটিংস',
	'edit_admin' => 'এডমিন সম্পাদনা',
	'new_admin' => 'নতুন এডমিন',
	'admin' => 'এডমিন',
];
