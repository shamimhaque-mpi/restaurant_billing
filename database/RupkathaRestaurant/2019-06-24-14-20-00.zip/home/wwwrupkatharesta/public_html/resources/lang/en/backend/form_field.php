<?php

return [
	"name" => "Name",
	"image" => "Image",
	"photo" => "Photo",
	"title" => "Title",
	"status" => "Status",
	"select_category" => "Select Category",
	"select_subcategory" => "Select Subcategory",
	"email" => "Email",
	"role" => "Role",
	"select_role" => "Select Role",
	"password" => "Password",
	"username" => "Username",
	'select_product' => 'Select Product',
];
