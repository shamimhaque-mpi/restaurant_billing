<?php

return [
	'menu' => 'Menu',
	'menu_management' => 'Menu Management',
	'menu_list' => 'Menu List',
	'add_menu' => 'Add Menu',
	'edit_menu' => 'Edit Menu',
	'delete_menu' => 'Delete Menu',
	'permission_management' => 'Permission Management',
	'menu_permission' => 'Menu Permission',
	'submenu' => 'Submenu',
	'menu_sort' => 'Menu Sort',
];
