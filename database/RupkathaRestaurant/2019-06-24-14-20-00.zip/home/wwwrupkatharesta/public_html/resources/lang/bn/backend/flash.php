<?php

return [
	'add_message' => 'সফলভাবে সংযোজন করা হয়েছে !!!',
	'update_message' => 'সফলভাবে আপডেট হয়েছে !!!',
	'delete_message' => 'সফলভাবে ডিলিট হয়েছে !!!',
	// 'delete_message' => ':option has been deleted successfully !!!',
	'deactive_message' => 'সফলভাবে নিষ্ক্রিয় হয়েছে !!!',
];
