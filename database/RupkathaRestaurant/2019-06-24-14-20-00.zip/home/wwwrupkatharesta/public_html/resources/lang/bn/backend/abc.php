<?php

return [
	'root_management' => 'মূল ব্যাবস্থাপনা',
];
