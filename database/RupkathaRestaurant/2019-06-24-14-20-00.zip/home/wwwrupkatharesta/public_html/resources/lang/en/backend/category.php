<?php

return [
	'category' => 'Category',
		'category_management' => 'Category Management',
		'edit_category' => 'Edit Category'
	];