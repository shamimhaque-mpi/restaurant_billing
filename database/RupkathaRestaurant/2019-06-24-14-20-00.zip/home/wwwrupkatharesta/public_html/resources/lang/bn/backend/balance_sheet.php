<?php

return[
	'balance_sheet' => 'ব্যালেন্স ‍শীট',
	'sales' => 'বিক্রয়',
	'purchases' => 'কেনাকাটা',
	'cost' => 'মূল্য',
	'invoice' => 'ইনভয়েস',
	'amount' => 'এমাউন্ট',
	'balance' => 'ব্যালেন্স',
];
