<?php

return [
	'unit' => 'একক',
	'add_unit' => 'একক যোগ করুন',
];