<?php

return [
'language_management' => 'Language Management',
'add_name' => 'Add Name',
'developer' => 'Developer',
'language' => 'Language',
'add_file' => 'Add File',
'my_admins' => 'All Admin',
'add_admin' => 'Add Admin',
];
