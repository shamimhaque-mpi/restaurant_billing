<?php

return [
	'product_management' => 'পণ্য ব্যবস্থাপনা',
	'product' => 'পণ্য',
	'add_product' => 'পণ্য যোগ করুন',
	'product_list' => 'পণ্য তালিকা',
	'select_category' => 'বিভাগ নির্বাচন করুন',
	'edit_product' => 'পণ্য সম্পাদনা',
	'regular_sale_price' => 'বিক্রয় মূল্য',
	'view_product' => 'পণ্য দেখুন',
];
