<?php

return[
	'access_information' => 'Access Information',
	'change_password' => 'Change Password',
	'role_management' => 'Role Management',
	'role' => 'Role',
	'assign' => 'Assign',
	'device' => 'Device',
	'browser' => 'Browser',
	'ip' => 'IP',
	'log_activity' => 'Log Activity',
	'admin_setting' => 'Admin Settings',
	'edit_admin' => 'Edit Admin',
	'admin' => 'Admin',
];
