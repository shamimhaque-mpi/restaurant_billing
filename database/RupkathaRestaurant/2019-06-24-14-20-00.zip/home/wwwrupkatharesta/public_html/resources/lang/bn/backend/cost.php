<?php

return [
	'cost_management' => 'খরচ ব্যাবস্থাপনা',
	'cost' => 'খরচ',
	'add_cost' => 'খরচ যোগ করুন',
	'cost_list' => 'খরচ তালিকা',
	'edit_cost' => 'খরচ সম্পাদনা',
	'cost_title' => 'খরচের টাইটেল',
	'cost_field_list' => 'খরচ ক্ষেত্রের তালিকা',
	'cost_field' => 'খরচ ক্ষেত্র',
	'add_cost_field' => 'খরচ ক্ষেত্র যোগ করুন',
	'cost_type' => 'খরচের ধরণ',
	'cost_by' => 'খরচকারী',
];
