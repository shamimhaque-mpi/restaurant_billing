<?php

return [
	'root_management' => 'Root Management',
];
