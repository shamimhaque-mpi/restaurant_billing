<?php

return [
	'product_management' => 'Product Management',
	'product' => 'Product',
	'add_product' => 'Add Product',
	'product_list' => 'Product List',
	'select_category' => 'Select Category',
	'edit_product' => 'Edit Product',
	'regular_sale_price' => 'Sale Price',
	'view_product' => 'View Product',
];
