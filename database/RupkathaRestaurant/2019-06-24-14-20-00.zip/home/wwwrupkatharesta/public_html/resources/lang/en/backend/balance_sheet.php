<?php

return[
	'balance_sheet' => 'Balance Sheet',
	'sales' => 'Sales',
	'purchases' => 'Purchase',
	'cost' => 'Cost',
	'invoice' => 'Invoice',
	'amount' => 'Amount',
	'balance' => 'Balance',
];
