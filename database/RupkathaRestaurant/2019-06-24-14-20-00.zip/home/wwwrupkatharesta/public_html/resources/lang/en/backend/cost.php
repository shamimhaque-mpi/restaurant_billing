<?php

return [
	'cost_management' => 'Cost Management',
	'cost' => 'Cost',
	'add_cost' => 'Add Cost',
	'cost_list' => 'Cost List',
	'edit_cost' => 'Edit Cost',
	'cost_title' => 'Cost Title',
	'cost_field_list' => 'Cost Field List',
	'cost_field' => 'Cost Field',
	'add_cost_field' => 'Add Cost Field',
	'cost_type' => 'Cost Type',
	'cost_by' => 'Cost By',
];
