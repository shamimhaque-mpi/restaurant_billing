<?php

return [
	'add_purchase_item' => 'পার্চেস আইটেম যোগ করুন',
	'purchase_item' => 'পার্চেস আইটেম',
	'edit_purchase_item' => 'পার্চেস আইটেম সম্পাদনা',
	'purchase_item_list' => 'পার্চেস আইটেম তালিকা',
	'add_purchase' => 'পার্চেস যোগ করুন',
	'purchase_list' => 'পার্চেস তালিকা',
	'purchase_history' => 'পার্চেস হিস্টরি',
	'edit_purchase' => 'পার্চেস সম্পাদনা',
	'history' => 'হিস্টরি',
];
