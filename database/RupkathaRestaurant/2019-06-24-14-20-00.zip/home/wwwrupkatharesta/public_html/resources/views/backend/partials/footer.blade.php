<footer class="footer text-center">
	All Rights Reserved by Company
	<a href="">Company</a>
</footer>
