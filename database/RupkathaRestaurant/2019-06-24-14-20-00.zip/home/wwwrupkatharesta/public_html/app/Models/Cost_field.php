<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cost_field extends Model
{
	protected $fillable = [
		'title', 'status', 'created_at', 'updated_at'
	];
}
