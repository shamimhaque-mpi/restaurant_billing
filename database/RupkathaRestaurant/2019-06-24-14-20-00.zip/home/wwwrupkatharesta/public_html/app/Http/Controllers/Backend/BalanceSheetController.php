<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Cost;
use DB;

class BalanceSheetController extends Controller
{
	public function __construct()
	{
		$this->middleware('auth:admin');
	}


	public function index(Request $request)
	{
		if($request->isMethod('post')){
			$sales = $this->searchSale($request->from_date, $request->to_date);
			$purchases = $this->searchPurchase($request->from_date, $request->to_date);
			$costs = $this->searchCost($request->from_date, $request->to_date);
		}
		else{
			$costs = $this->getTodayCost();
			$purchases = $this->getTodayPurchase();
			$sales = $this->getTodaySale();
		}


		return view('backend.pages.balance_sheet.index', compact('costs', 'purchases', 'sales'));
	}


	private function getTodaySale()
	{
		$todayDate = date('Y-m-d');

		$sales = DB::table('sales')
		->where('status', 1)
		->whereDate('sales.created_at', '=', $todayDate)
		->select('*')
		->get();

		return $sales;
	}

	private function getTodayPurchase()
	{
		$todayDate = date('Y-m-d');

		$purchases = DB::table('costs')
		->where('status', 1)
		->where('cost_type', 'Purchase')
		->whereDate('costs.pickdate', '=', $todayDate)
		->select('*')
		->get();

		return $purchases;
	}

	private function getTodayCost()
	{
		$todayDate = date('Y-m-d');

		$costs = DB::table('costs')
		->where('status', 1)
		->where('cost_type', 'General')
		->whereDate('costs.pickdate', '=', $todayDate)
		->select('*')
		->get();

		return $costs;
	}

	private function searchSale($from, $to=null)
	{
		if($to && $from && $from != $to){
			$to = date('Y-m-d', strtotime($to . ' +1 day'));
			$sales = DB::table('sales')
			->where('status', 1)
			->whereBetween('sales.created_at', [$from, $to])
			->select('*')
			->get();
		}
		else{
			$sales = DB::table('sales')
			->where('status', 1)
			->whereDate('sales.created_at', '=', $from)
			->select('*')
			->get();
		}

		return $sales;
	}	

	private function searchPurchase($from, $to=null)
	{
		if($to && $from && $from != $to){
			$to = date('Y-m-d', strtotime($to . ' +1 day'));
			$purchases = DB::table('costs')
			->where('status', 1)
			->where('cost_type', 'Purchase')
			->whereBetween('costs.pickdate', [$from, $to])
			->select('*')
			->get();
		}
		else{
			$purchases = DB::table('costs')
			->where('status', 1)
			->where('cost_type', 'Purchase')
			->whereDate('costs.pickdate', '=', $from)
			->select('*')
			->get();
		}

		return $purchases;
	}

	private function searchCost($from, $to=null)
	{
		if($to && $from && $from != $to){
			// $to = date('Y-m-d', strtotime($to . ' +1 day'));
			$costs = DB::table('costs')
			->where('status', 1)
			->where('cost_type', 'General')
			->whereBetween('costs.pickdate', [$from, $to])
			->select('*')
			->get();
		}
		else{
			$costs = DB::table('costs')
			->where('status', 1)
			->where('cost_type', 'General')
			->whereDate('costs.pickdate', '=', $from)
			->select('*')
			->get();
		}

		return $costs;
	}
}
