<?php $__env->startSection('fav_title', 'Add Category'); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
  <div>
    <h1><i class="fa fa-pie-chart"></i> <?php echo e(__('backend/category.category_management')); ?></h1>
  </div>
  <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg fa-fw"></i><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('backend/default.dashboard')); ?></a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.category.index')); ?>"><?php echo e(__('backend/category.category')); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e(__('backend/default.add_new')); ?></li>
  </ul>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <div class="row">
          <div class="col-md-6"><h2><i class="fa fa-plus-square"></i> <?php echo e(__('backend/category.category')); ?></h2></div>
          <div class="col-md-6"><a href="<?php echo e(route('admin.category.index')); ?>" class="float-right btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/default.list')); ?></a></div>
          <div class="clearfix"></div>
        </div>
      </div>

      <div class="card-body">
        <?php echo $__env->make('backend.partials.error_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form class="form-horizontal" id="myform" action="<?php echo e(route('admin.category.store')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>

          <div class="form-group row">
            <label class="control-label col-md-3 text-right">
              <strong><?php echo e(__('backend/form_field.name')); ?></strong>
              <span class="text-danger">*</span></label>
            <div class="col-md-5">
              <input type="text" id="title" class="form-control" type="text" name="title"  required>
            </div>
          </div>

          <div class="form-group row">
            <label class="control-label col-md-3 text-right">
              <strong><?php echo e(__('backend/form_field.photo')); ?></strong>
              <span class="text-danger">*</span></label>
            <div class="col-md-5">
              <input type="file" id="image" class="form-control" type="text" name="image" required>
            </div>
          </div>

          <div class="form-group row">
            <label class="control-label col-md-3 text-right" for="status">
            <strong><?php echo e(__('backend/form_field.status')); ?></strong>  <span class="text-danger">*</span></label>
            <div class="col-md-5">
              <select name="status" id="status" class="form-control" required>
                <option value="1">Active</option>
                <option value="0">Deactive</option>
              </select>
            </div>
          </div>
          
          <div class="form-row">
            <div class="col-md-8 mt-3">
              <button type="submit" name="save" class="btn btn-primary float-right"><?php echo e(__('backend/default.submit')); ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\restaurent-bill\resources\views/backend/pages/category/add.blade.php ENDPATH**/ ?>