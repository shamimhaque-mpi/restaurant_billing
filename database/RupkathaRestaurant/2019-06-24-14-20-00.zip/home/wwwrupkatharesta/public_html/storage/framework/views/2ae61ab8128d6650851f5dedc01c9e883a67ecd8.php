<!-- Full Structure -->


<?php $__env->startSection('fav_title', __('backend/purchase_item.add_purchase') ); ?>

<!-- Write Styles <style>In Here</style> -->
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<!-- This Section Will Shown <body>In Here</body> -->
<?php $__env->startSection('content'); ?>
<!-- Top Management Part -->
<div class="app-title">
	<div>
		<h1><i class="<?php echo e('fa fa-sitemap'); ?>"></i> <?php echo e(__('backend/purchase_item.purchase_item_management')); ?></h1>
	</div>
	<ul class="app-breadcrumb breadcrumb">
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('backend/default.dashboard')); ?></a></li>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.purchase_item.index')); ?>"><?php echo e(__('backend/purchase_item.purchase_item')); ?></a></li>
		<li class="breadcrumb-item active"><?php echo e(__('backend/default.add_new')); ?></li>
	</ul>
</div>

<!-- Add Form Part -->
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header">
				<div class="row">
					<div class="col-md-6"><h2><i class="<?php echo e('fa fa-plus-square'); ?>"></i> <?php echo e(__('backend/purchase_item.add_purchase')); ?></h2></div>
					<div class="col-md-6"><a href="<?php echo e(route('admin.purchase.index')); ?>" class="float-right btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/purchase_item.history')); ?></a></div>
					<div class="clearfix"></div>

				</div>
			</div>
			<div class="card-body">
				<?php echo $__env->make('backend.partials.error_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<form class="form-horizontal" action="<?php echo e(route('admin.purchase.store')); ?>" method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>

	                <div class="form-row alert-info br-2 p-2 pt-3 mb-3">
	                    <div class="col-md-6">
	                        
	                        <div>
	                            <input autocomplete="off" type="text" class="form-control mb-2 purchase_date" name="purchase_date" id="purchase_date" required>
	                        </div>
	                    </div>
	                    <div class="col-md-6 btn btn-success" id="add_prepand_button" style="height: 37px;">Add Another</div>
	                </div>
	                <div id="prepand_in">
		                <div class="form-row alert-warning br-2 p-2 pt-3" id="prepand_me">
		                    <div class="col-md-4 item_container">
		                        <label for="purchase_item_id" class="label">Purchase Item</label>
		                        <div>
		                        	<select name="purchase_item_id[]" id="purchase_item_id" class="form-control purchase_item_id" required="">
		                        		<option selected="" disabled="">--Select Item--</option>
		                        		<?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        			<option value="<?php echo e($row->id); ?>" data-regular_price_<?php echo e($row->id); ?>="<?php echo e($row->regular_price); ?>"><?php echo e($row->title); ?></option>
		                        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                        	</select>
		                        </div>
		                    </div>
		                    <div class="col-md-4 mb-2">
		                        <label for="price" class="label">Purchase Price</label>
		                        <div>
		                        	<input type="number" step=".5" class="form-control mb-2 price" name="price[]" id="price" required>
		                        </div>
		                    </div>
		                    <div class="col-md-4 mb-2">
		                        <label for="quantity" class="label">Quantity</label>
		                        <div>
		                            <input type="number" step=".1" class="form-control mb-2" name="quantity[]" id="quantity" required>
		                        </div>
		                    </div>
		                </div>
					</div>
					<button type="submit" class="btn btn-primary float-right"><?php echo e(__('backend/default.submit')); ?></button>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<!-- Write Scripts <script fileType="text/javascript">In Here</script> -->
<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		
		var $prepend_html = $('#prepand_in').html();


		$(".purchase_date").val("<?php echo e(date('Y-m-d')); ?>");
		$(document).ready(function() {


			getValueOfItem();

			$("#add_prepand_button").on('click', function(event) {
				$("#prepand_in").prepend($prepend_html);
				$(".purchase_item_id").select2();
				getValueOfItem();
			});

			$(".purchase_item_id").select2();
			$(".purchase_date").datepicker({
			    format: 'yyyy-mm-dd',
			    todayHighlight:'TRUE',
			    autoclose: true,
			});

		});

		function getValueOfItem() {
			$(".purchase_item_id").on('change', function(event) {
				$(this).closest('.item_container').next().find('.price').val($('option:selected', this).data('regular_price_'+$(this).val()));
			});
		}
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wwwrupkatharesta/public_html/resources/views/backend/pages/purchase/add.blade.php ENDPATH**/ ?>