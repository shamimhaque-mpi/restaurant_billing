<!-- Full Structure -->


<?php $__env->startSection('fav_title', __('backend/purchase_item.edit_purchase_item') ); ?>

<!-- Write Styles <style>In Here</style> -->
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<!-- This Section Will Shown <body>In Here</body> -->
<?php $__env->startSection('content'); ?>
<!-- Top Management Part -->
<div class="app-title">
	<div>
		<h1><i class="<?php echo e('fa fa-sitemap'); ?>"></i> <?php echo e(__('backend/purchase_item.purchase_item_management')); ?></h1>
	</div>
	<ul class="app-breadcrumb breadcrumb">
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('backend/default.dashboard')); ?></a></li>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.purchase_item.index')); ?>"><?php echo e(__('backend/purchase_item.purchase_item')); ?></a></li>
		<li class="breadcrumb-item active"><?php echo e(__('backend/default.edit')); ?></li>
	</ul>
</div>

<!-- Edit Form Part -->
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header">
				<div class="row">
					<div class="col-md-6"><h2><i class="<?php echo e('fa fa-pencil-square'); ?>"></i> <?php echo e(__('backend/purchase_item.edit_purchase_item')); ?></h2></div>
					<div class="col-md-6"><a href="<?php echo e(route('admin.purchase_item.index')); ?>" class="float-right btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/default.list')); ?></a></div>
					<div class="clearfix"></div>
				</div>
			</div>
			<div class="card-body">
				<?php echo $__env->make('backend.partials.error_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<form class="form-horizontal" action="<?php echo e(route('admin.purchase_item.update',$row->id)); ?>" method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>

	                <div class="form-row">
	                    <div class="col-md-6">
	                        <label for="title" class="label">Title</label>
	                        <div>
	                            <input type="text" class="form-control mb-2" value="<?php echo e($row->title); ?>" name="title" id="title" required>
	                        </div>
	                        <label for="regular_price" class="label">Regular Price</label>
	                        <div>
	                            <input type="number" step=".5" class="form-control mb-2" value="<?php echo e($row->regular_price); ?>" name="regular_price" id="regular_price" required>
	                        </div>
	                        <label for="status" class="label">Status</label>
	                        <div>
	                        	<select name="status" id="status" class="form-control">
	                        		<option value="1" <?php echo e($row->status == 1 ? 'selected' : ''); ?>>Active</option>
	                        		<option value="0" <?php echo e($row->status == 0 ? 'selected' : ''); ?>>Deactive</option>
	                        	</select>
	                        </div>
	                    </div>
	                    <div class="col-md-6 mb-2">
	                        <label for="description" class="label">Description</label>
	                        <div>
	                            <textarea style="height: 185px;" class="form-control" name="description" id="description"><?php echo $row->description; ?></textarea>
	                        </div>
	                    </div>
	                </div>


					<button type="submit" class="btn btn-primary float-right"><?php echo e(__('backend/default.update')); ?></button>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<!-- Write Scripts <script fileType="text/javascript">In Here</script> -->
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\rupkatharestaurant\resources\views/backend/pages/purchase/purchase_item/edit.blade.php ENDPATH**/ ?>