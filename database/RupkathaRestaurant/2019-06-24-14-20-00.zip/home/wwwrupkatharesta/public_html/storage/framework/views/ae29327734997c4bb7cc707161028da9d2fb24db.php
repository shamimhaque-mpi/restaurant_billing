<?php $__env->startSection('fav_title', __('backend/menu.menu_permission') ); ?>

<?php $__env->startSection('styles'); ?>
<style type="text/css">
  .methods > .each_method{
    float: left;
    width: 184px;
    padding: 10px 0;
  }
  .table th, .table td{
    vertical-align: middle;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
  <div>
    <h1><i class="fa fa-gavel"></i> <?php echo e(__('backend/menu.permission_management')); ?></h1>
  </div>
  <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg fa-fw"></i><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('backend/default.dashboard')); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e(__('backend/admin_setting.admin_setting')); ?></li>
    <li class="breadcrumb-item active"><?php echo e(__('backend/admin_setting.role')); ?></li>
  </ul>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <h2><i class="fa fa-table"> </i> <?php echo e(__('backend/admin_setting.role')); ?></h2>
      </div>
      <div class="card-body">
        <?php
        $permissions = \App\Models\Menu::orderBy('id', 'desc')->where('url', substr(url()->current(), 1+strlen(url('/'))))
        ->orWhere('url', substr(url()->current(), strlen(url('/'))))->first();
        $bodyMenu = \App\Models\Role::where('role', Auth::guard('admin')->user()->admin_role)->first();
        ?>
        <div class="table-reponsive">
          <table class="table table-striped table-bordered">
            <thead>
              <th><?php echo e(__('backend/default.sl')); ?></th>
              <th><?php echo e(__('backend/admin_setting.role')); ?></th>
              <th><?php echo e(__('backend/default.action')); ?></th>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>Super Admin</td>
                <td>
                  <?php $__currentLoopData = $permissions->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(\App\Models\Menu::checkBodyMenu($permission->id, $bodyMenu->in_body)): ?>
                  <a class="btn btn-primary" href="<?php echo e(route($permission->route, 'super-admin')); ?>"
                    ><i class="<?php echo e($permission->icon); ?>"></i></a>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>Admin</td>
                  <td>
                    <?php $__currentLoopData = $permissions->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(\App\Models\Menu::checkBodyMenu($permission->id, $bodyMenu->in_body)): ?>
                    <a class="btn btn-primary" href="<?php echo e(route($permission->route, 'admin')); ?>"
                      ><i class="<?php echo e($permission->icon); ?>"></i></a>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td>User</td>
                    <td>
                      <?php $__currentLoopData = $permissions->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(\App\Models\Menu::checkBodyMenu($permission->id, $bodyMenu->in_body)): ?>
                      <a class="btn btn-primary" href="<?php echo e(route($permission->route, 'user')); ?>"
                        ><i class="<?php echo e($permission->icon); ?>"></i></a>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php $__env->stopSection(); ?>

      <?php $__env->startSection('scripts'); ?>
      <script>
        $(document).ready(function () {
          $(document).on('change', '.select_all', function () {
            var change = $(this);
            $(this).closest('tr').find('.methods').find('input').each(function () {
              if (change.is(':checked')) {
                $(this).prop('checked', true);
              }
              else {
                $(this).prop('checked', false);
              }
            });
          });
        });
      </script>
      <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\restaurent-bill\resources\views/backend/pages/role/index.blade.php ENDPATH**/ ?>