<!-- Full Structure -->


<?php $__env->startSection('fav_title', __('backend/product.product') ); ?>

<!-- Write Styles <style>In Here</style> -->
<?php $__env->startSection('styles'); ?>
<style type="text/css">
	td.p-1{
		text-align: center;
	}
</style>
<?php $__env->stopSection(); ?>

<!-- This Section Will Shown <body>In Here</body> -->
<?php $__env->startSection('content'); ?>
<!-- Top Management Part -->
<div class="app-title">
	<div>
		<h1><i class="<?php echo e('fa fa-archive'); ?>"></i> <?php echo e(__('backend/product.product_management')); ?></h1>
	</div>
	<ul class="app-breadcrumb breadcrumb">
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('backend/default.dashboard')); ?></a></li>
		<?php if('index' == 'index'): ?>
		<li class="breadcrumb-item active"><?php echo e(__('backend/product.product')); ?></li>
		<?php elseif('index' == 'add'): ?>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.product.index')); ?>"><?php echo e(__('backend/product.product')); ?></a></li>
		<li class="breadcrumb-item active"><?php echo e(__('backend/default.add_new')); ?></li>
		<?php elseif('index' == 'edit'): ?>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.product.index')); ?>"><?php echo e(__('backend/product.product')); ?></a></li>
		<li class="breadcrumb-item active"><?php echo e(__('backend/default.edit')); ?></li>
		<?php endif; ?>
	</ul>
</div>

<!-- Table Part -->
<div class="row">
	<div class="col-md-12">
		<div class="card">

			<div class="card-header">
				<div class="row">
					<?php if('index' == 'index'): ?>
					<div class="col-md-6"><h2><i class="<?php echo e('fa fa-table'); ?>"></i> <?php echo e(__('backend/product.product_list')); ?></h2></div>
					<div class="col-md-6"><a href="<?php echo e(route('admin.product.create')); ?>" class="float-right btn btn-primary"><i class="fa fa-plus"></i> <?php echo e(__('backend/default.add_new')); ?></a></div>

					<?php elseif('index' == 'add'): ?>
					<div class="col-md-6"><h2><i class="<?php echo e('fa fa-table'); ?>"></i> <?php echo e(__('backend/product.add_product')); ?></h2></div>
					<div class="col-md-6"><a href="<?php echo e(route('admin.product.index')); ?>" class="float-right btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/default.list')); ?></a></div>

					<?php elseif('index' == 'edit'): ?>
					<div class="col-md-6"><h2><i class="<?php echo e('fa fa-table'); ?>"></i> <?php echo e(__('backend/product.edit_product')); ?></h2></div>
					<div class="col-md-6"><a href="<?php echo e(route('admin.product.index')); ?>" class="float-right btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/default.list')); ?></a></div>
					<?php endif; ?>
					<div class="clearfix"></div>
				</div>
			</div>

			<div class="card-body">
                <form action="<?php echo e(route('admin.product.index')); ?>" method="post">
					<?php echo csrf_field(); ?>
					<div class="row mb-3">
						
        				<div class="col-md-4 col-sm-10 ml-2">
        				    <select name="category__" id="category__" class="form-control">>
        				        <option disabled selected>Select Category</option>
        				        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        				        <option <?php echo e($_category ==  $category->id ? 'selected' : ''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
        				        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        				    </select>
        				</div>
        				
					    <button class="btn btn-primary searchByDate col-md-1 col-sm-2" type="submit"><?php echo e(__('backend/default.search')); ?></button>

					</div>
				</form>
				<!-- Permission for Admin Access -->
				<?php
				$permissions = \App\Models\Menu::where('url', substr(url()->current(), 1+strlen(url('/'))))
				->orWhere('url', substr(url()->current(), strlen(url('/'))))->first();
				if(Auth::guard('admin')->user()->admin_role == 3){
					$bodyMenu = \App\Models\Role::where('admin_id', Auth::guard()->id())->first();
				}
				else{
					$bodyMenu = \App\Models\Role::where('role', Auth::guard()->user()->admin_role)->first();
				}
				?>


				<div class="toggle-table-column alert-info br-2 p-2 mb-2">
					<strong><?php echo e(__('backend/default.table_toggle_message')); ?> </strong>
					<br>

					<a href="#" class="toggle-vis" data-column="0"><b><?php echo e(__('backend/default.sl')); ?></b></a> |
					<a href="#" class="toggle-vis" data-column="1"><b><?php echo e(__('backend/default.title')); ?></b></a> |
					<a href="#" class="toggle-vis" data-column="2"><b><?php echo e(__('backend/default.photo')); ?></b></a> |
					<a href="#" class="toggle-vis" data-column="3"><b><?php echo e(__('backend/category.category')); ?></b></a> |
					<a href="#" class="toggle-vis" data-column="4"><b><?php echo e(__('backend/default.purchase_price')); ?></b></a> |
					<a href="#" class="toggle-vis" data-column="5"><b><?php echo e(__('backend/product.regular_sale_price')); ?></b></a> |
					<a href="#" class="toggle-vis" data-column="6"><b><?php echo e(__('backend/default.status')); ?></small></b></a> |
					<a href="#" class="toggle-vis" data-column="7"><b><?php echo e(__('backend/default.action')); ?></small></b></a>

				</div>
				<div class="table-responsive pt-1">
					<table id="datatable" class="table table-bordered table-hover display">

						<thead>
							<th><?php echo e(__('backend/default.sl')); ?></th>
							<th><?php echo e(__('backend/default.title')); ?></th>
							<th><?php echo e(__('backend/default.photo')); ?></th>
							<th><?php echo e(__('backend/category.category')); ?></th>
							<th><?php echo e(__('backend/default.purchase_price')); ?></th>
							<th><?php echo e(__('backend/product.regular_sale_price')); ?></th>
							<th><?php echo e(__('backend/default.status')); ?></th>
							<th class="action"><?php echo e(__('backend/default.action')); ?></th>
						</thead>
						<tbody>


							<?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr class="<?php echo e($row->status == 0 ? 'deactive_':''); ?>">
								<td><?php echo e($loop->index+1); ?></td>
								<td><?php echo e($row->title); ?></td>
								<td class="p-1">
									<img src="<?php echo e(asset($row->image)); ?>" class="img-thumbnail" style="height: 62px;">
								</td>
								<td>
									<!-- <i class="fa fa-pie-chart"></i> -->
									 <?php echo e($row->category->title); ?>

								</td>
								<td><?php echo e($row->purchase_price); ?></td>
								<td><?php echo e($row->regular_sale_price); ?></td>
								<td><?php echo e($row->status == 1 ? 'Actived' : 'Deactived'); ?></td>
								<td class="action">
									<div class="btn-group">

										<!-- Checking Admin Access -->
										<?php $__currentLoopData = $permissions->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if(\App\Models\Menu::checkBodyMenu($permission->id, $bodyMenu->in_body)): ?>
                                        <?php if($key == 0): ?>
                                        <a href="<?php echo e(route($permission->route, $row->slug)); ?>" class="btn btn-info"><i class="fa fa-eye"></i></a>
                                        <?php elseif($key == 1): ?>
                                        <a href="<?php echo e(route($permission->route, $row->slug)); ?>" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                                        <?php else: ?>
                                        <button class="btn <?php echo e($row->status == 0 ? 'btn-secondary disabled':' btn-danger'); ?>" onClick="deleteMethod(<?php echo e(json_encode($row->id)); ?>)" role="button" <?php echo e($row->status == 0? 'disabled':''); ?>><i class="fa fa-minus-circle"></i></button>
                                        <?php endif; ?>
										<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</tbody>
					</table>

				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<!-- Write Scripts <script fileType="text/javascript">In Here</script> -->
<?php $__env->startSection('scripts'); ?>
<script>
    $('#category__').select2();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\rupkatharestaurant\resources\views/backend/pages/product/index.blade.php ENDPATH**/ ?>