<!-- Full Structure -->


<?php $__env->startSection('fav_title', __('backend/product.add_product') ); ?>

<!-- Write Styles <style>In Here</style> -->
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<!-- This Section Will Shown <body>In Here</body> -->
<?php $__env->startSection('content'); ?>
<!-- Top Management Part -->
<div class="app-title">
	<div>
		<h1><i class="<?php echo e('fa fa-archive'); ?>"></i> <?php echo e(__('backend/product.product_management')); ?></h1>
	</div>
	<ul class="app-breadcrumb breadcrumb">
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('backend/default.dashboard')); ?></a></li>
		<?php if('add' == 'index'): ?>
		<li class="breadcrumb-item active"><?php echo e(__('backend/product.product')); ?></li>
		<?php elseif('add' == 'add'): ?>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.product.index')); ?>"><?php echo e(__('backend/product.product')); ?></a></li>
		<li class="breadcrumb-item active"><?php echo e(__('backend/default.add_new')); ?></li>
		<?php elseif('add' == 'edit'): ?>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.product.index')); ?>"><?php echo e(__('backend/product.product')); ?></a></li>
		<li class="breadcrumb-item active"><?php echo e(__('backend/default.edit')); ?></li>
		<?php endif; ?>
	</ul>
</div>

<!-- Add Form Part -->
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header">
				<div class="row">
					<?php if('add' == 'index'): ?>
					<div class="col-md-6"><a href="<?php echo e(route('admin.product.create')); ?>" class="float-right btn btn-primary"><i class="fa fa-plus"></i> <?php echo e(__('backend/default.add_new')); ?></a></div>

					<?php elseif('add' == 'add'): ?>
					<div class="col-md-6"><h2><i class="<?php echo e('fa fa-plus-square'); ?>"></i> <?php echo e(__('backend/product.add_product')); ?></h2></div>
					<div class="col-md-6"><a href="<?php echo e(route('admin.product.index')); ?>" class="float-right btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/default.list')); ?></a></div>

					<?php elseif('add' == 'edit'): ?>
					<div class="col-md-6"><h2><i class="<?php echo e('fa fa-plus-square'); ?>"></i> <?php echo e(__('backend/product.edit_product')); ?></h2></div>
					<div class="col-md-6"><a href="<?php echo e(route('admin.product.index')); ?>" class="float-right btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/default.list')); ?></a></div>
					<?php endif; ?>
					<div class="clearfix"></div>
				</div>
			</div>
			<div class="card-body">
				<?php echo $__env->make('backend.partials.error_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<form class="form-horizontal" action="<?php echo e(route('admin.product.store')); ?>" method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>

					<div class="form-row">
						<div class="col-md-6 form-group mb-0">
							<div class="form-group">
								<label for="title"><?php echo e(__('backend/default.title')); ?> <span class="text-danger">*</span></label>
								<input type="text" class="form-control" name="title" id="title" required placeholder="">
							</div>

							<div class="form-group">
								<label for="category_id"><?php echo e(__('backend/category.category')); ?> <span class="text-danger">*</span></label>
								<select name="category_id" id="category_id" class="form-control" required>
									<option selected disabled><?php echo e(__('backend/product.select_category')); ?></option>
									<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							</div>
							<div class="form-group">
								<label for="status"><?php echo e(__('backend/default.status')); ?> <span class="text-danger">*</span></label>
								<select name="status" id="status" class="form-control" required>
									<option value="1"><?php echo e(__('backend/default.active')); ?></option>
									<option value="0"><?php echo e(__('backend/default.deactive')); ?></option>
								</select>
							</div>
						</div>
						<div class="col-md-6 form-group mb-0">
							<label for="description"><?php echo e(__('backend/default.description')); ?> <span class="text-danger">*</span></label>
							<textarea name="description" id="description" class="form-control" cols="30" rows="4" required style="min-height: 200px"></textarea>
						</div>
					</div>

					<div class="form-row">
						<div class="col-md-5 form-group">
							<label for="purchase_price"><?php echo e(__('backend/default.purchase_price')); ?> <span class="text-danger">*</span></label>
							<input type="number" class="form-control" name="purchase_price" id="purchase_price" required placeholder="">
						</div>

						<div class="col-md-5 form-group">
							<label for="regular_sale_price"><?php echo e(__('backend/default.regular_sale_price')); ?> <span class="text-danger">*</span></label>
							<input type="number" class="form-control" name="regular_sale_price" id="regular_sale_price" required placeholder="">
						</div>
						<div class="col-md-2 form-group">
							<label for="discount"><?php echo e(__('backend/default.discount')); ?> <span class="text-danger">*</span> <small>(<?php echo e(__('backend/default.in_%')); ?>)</small></label>
							<input type="number" min="0" max="100" class="form-control" name="discount" id="discount" placeholder="" required>
						</div>
					</div>

					<div class="form-row" id="img">
						<div class="col-md-3 form-group position-relative">
							<label for="image"><?php echo e(__('backend/default.photo')); ?> <span class="text-danger">*</span></label>
							<input type="file" class="form-control img_" name="image" id="image" required>
							<img class="image_preview position-absolute img_prv" src="">
						</div>
					</div>


					<button type="submit" class="btn btn-primary float-right"><?php echo e(__('backend/default.submit')); ?></button>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<!-- Write Scripts <script fileType="text/javascript">In Here</script> -->
<?php $__env->startSection('scripts'); ?>
<script>
	$(document).ready(function(){

		$('#category_id').select2();

        // $('#productForm').validate({ // initialize the plugin
        // 	rules: {
        // 		title: {
        // 			required: true,
        // 		},
        // 	},
        // 	messages: {
        // 		title: "<?php echo e(__('backend/default.required_validation')); ?>",
        // 		description: "<?php echo e(__('backend/default.required_validation')); ?>",
        // 		purchase_price: "<?php echo e(__('backend/default.required_validation')); ?>",
        // 		regular_sale_price: "<?php echo e(__('backend/default.required_validation')); ?>",
        // 		quantity: "<?php echo e(__('backend/default.required_validation')); ?>",
        // 		"image[]": "<?php echo e(__('backend/default.required_validation')); ?>",
        // 		status: "<?php echo e(__('backend/default.required_validation')); ?>",
        // 	}
        // });
        $('body').on('click','.img_',function(){
        	$(this).change(function(){
        		$('.img_prv').attr('src', window.URL.createObjectURL(this.files[0]));

        		// Don't Delete

        		/*$('.img_prv').removeClass('img_prv');
        		$(this).removeClass('img_');
        		$(this).attr('readonly','""');
        		var newImage = "<div class=\"col-md-3 form-group\">\n" +
        		"					<label for=\"image\"> <span class=\"text-danger\">&nbsp;</span> </label>\n" +
        		"					<input type=\"file\" class=\"form-control img_\" name=\"image[]\">\n" +
        		"					<img class=\"image_preview position-absolute img_prv\" src=\"\">" +
        		"               </div>";
        		$("#img").append(newImage);*/
        	});
        })

    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\restaurent-bill\resources\views/backend/pages/product/add.blade.php ENDPATH**/ ?>