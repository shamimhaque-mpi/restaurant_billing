<!-- Full Structure -->


<?php $__env->startSection('fav_title', __('backend/cost_field.cost_field') ); ?>

<!-- Write Styles <style>In Here</style> -->
<?php $__env->startSection('styles'); ?>
<style>
  .action{
    min-width: 70px;
  }
  .table th, .table td{
    vertical-align: middle;
  }
</style>
<?php $__env->stopSection(); ?>

<!-- This Section Will Shown <body>In Here</body> -->
<?php $__env->startSection('content'); ?>
<!-- Top Management Part -->
<div class="app-title">
  <div>
    <h1><i class="fa fa-contao"></i> <?php echo e(__('backend/cost.cost_field')); ?> <?php echo e(__('backend/default.management')); ?></h1>
  </div>
  <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('backend/default.dashboard')); ?></a></li>
    <li class="breadcrumb-item"><?php echo e(__('backend/cost.cost_field')); ?></li>
  </ul>
</div>

<!-- Table Part -->
<div class="row">
  <div class="col-md-12">
    <div class="card">

      <div class="card-header">
        <div class="row">
          <div class="col-md-6"><h2><i class="<?php echo e('fa fa-table'); ?>"></i> <?php echo e(__('backend/cost.cost_field_list')); ?></h2></div>
          <div class="col-md-6"><button data-toggle="modal" data-target="#add_new" class="float-right btn btn-primary"><i class="fa fa-plus"></i> <?php echo e(__('backend/default.add_new')); ?></button></div>
          <div class="clearfix"></div>
        </div>
      </div>

      <div class="card-body">
        <?php echo $__env->make('backend.partials.error_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php
        $permissions = \App\Models\Menu::orderBy('id', 'desc')->where('url', substr(url()->current(), 1+strlen(url('/'))))
        ->orWhere('url', substr(url()->current(), strlen(url('/'))))->first();
        if(Auth::guard('admin')->user()->admin_role == 3){
          $bodyMenu = \App\Models\Role::where('admin_id', Auth::guard()->id())->first();
        }
        else{
          $bodyMenu = \App\Models\Role::where('role', Auth::guard()->user()->admin_role)->first();
        }
        ?>
        <div class="toggle-table-column alert-info br-2 p-2 mb-2">
          <strong><?php echo e(__('backend/default.table_toggle_message')); ?> </strong>
          <br>

          <a href="#" class="toggle-vis" data-column="0"><b><?php echo e(__('backend/default.sl')); ?></b></a> |
          <a href="#" class="toggle-vis" data-column="1"><b><?php echo e(__('backend/default.title')); ?></b></a> |
          <a href="#" class="toggle-vis" data-column="2"><b><?php echo e(__('backend/default.status')); ?></small></b></a> |
          <a href="#" class="toggle-vis" data-column="3"><b><?php echo e(__('backend/default.action')); ?></small></b></a>

        </div>

        <div class="table-responsive pt-1">
          <table id="datatable" class="table table-bordered table-hover display">

            <thead>
              <th><?php echo e(__('backend/default.sl')); ?></th>
              <th><?php echo e(__('backend/default.title')); ?></th>
              <th><?php echo e(__('backend/default.status')); ?></th>
              <th class="action"><?php echo e(__('backend/default.action')); ?></th>
            </thead>

            <tbody>

              <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="<?php echo e($row->status == 0 ? 'deactive_':''); ?>">
                <td><?php echo e($loop->index + 1); ?></td>
                <td><?php echo e($row->title); ?></td>
                <td><?php echo e($row->status == 1 ? 'Active' : 'Deactive'); ?></td>
                <td class="action">
                  <div class="btn-group">
                    <?php $__currentLoopData = $permissions->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(\App\Models\Menu::checkBodyMenu($permission->id, $bodyMenu->in_body)): ?>
                    <?php if($key == 0): ?>
                    <button data-toggle="modal" data-target="#edit_page<?php echo e($row->id); ?>" class="btn btn-info text-white"><i class="fa fa-edit"></i></button>
                    <?php else: ?>
                    <button class="btn text-white <?php echo e($row->status == 0? ' btn-secondary disabled':' btn-danger'); ?>" onClick="deleteMethod(<?php echo e($row->id); ?>)" role="button" <?php echo e($row->status == 0? 'disabled':''); ?>><i class="fa fa-minus-circle"></i></button>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                  <!-- Edit Modal -->
                  <div class="modal fade" id="edit_page<?php echo e($row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-pencil-square"></i> <?php echo e(__('backend/cost.cost')); ?> <?php echo e(__('backend/default.update')); ?></h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <form action="<?php echo e(route('admin.cost_field.update', $row->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                              <label class="col-form-label" for="title"><?php echo e(__('backend/default.title')); ?><span class="text-danger">*</span></label>
                              <div>
                                <input type="text" class="form-control" name="title" id="title" value="<?php echo e($row->title); ?>" required>
                              </div>
                            </div>
                            <div class="form-group">
                              <label class="col-form-label" for="status"><?php echo e(__('backend/default.status')); ?> <span class="text-danger">*</span></label>
                              <div>
                                <select class="form-control" name="status" id="status" required>
                                  <option value="1" <?php echo e($row->status==1 ? 'selected': ''); ?>><?php echo e(__('backend/default.active')); ?></option>
                                  <option value="0" <?php echo e($row->status==0 ? 'selected': ''); ?>><?php echo e(__('backend/default.deactive')); ?></option>
                                </select>
                              </div>
                            </div>
                            
                            <div class="button-group pull-right">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo e(__('backend/default.close')); ?></button>
                              <button type="submit" class="btn btn-primary"><?php echo e(__('backend/default.update')); ?></button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="add_new" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-plus-square"></i> <?php echo e(__('backend/cost.add_cost_field')); ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('admin.cost_field.store')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label class="col-form-label" for="title"><?php echo e(__('backend/default.title')); ?><span class="text-danger">*</span></label>
            <div>
              <input type="text" class="form-control" name="title" id="title" required>
            </div>
          </div>
          <div class="form-group">
            <label class="col-form-label" for="status"><?php echo e(__('backend/default.status')); ?> <span class="text-danger">*</span></label>
            <div>
              <select class="form-control" name="status" id="status" required>
                <option value="1"><?php echo e(__('backend/default.active')); ?></option>
                <option value="0"><?php echo e(__('backend/default.deactive')); ?></option>
              </select>
            </div>
          </div>
          <div class="button-group pull-right">
            <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo e(__('backend/default.close')); ?></button>
            <button type="submit" class="btn btn-primary"><?php echo e(__('backend/default.submit')); ?></button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wwwrupkatharesta/public_html/resources/views/backend/pages/cost_field/index.blade.php ENDPATH**/ ?>