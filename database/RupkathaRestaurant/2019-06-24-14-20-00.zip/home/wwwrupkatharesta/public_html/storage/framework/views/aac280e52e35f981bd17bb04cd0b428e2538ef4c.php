<div class="col-sm-12 col-md-6 pull-left mb-3">
  <div class="row">    
    <?php if(isset($where) && $total > 0): ?>

      <div class="alert alert-success" style="height: 38px; padding: 8px; margin-bottom: 8px;">
        <span class="text-success">Total <strong><?php echo e($total); ?></strong> entities found</span>
      </div>

    <?php elseif(!isset($where)): ?>

      <div class="col-sm-12"  style="float: left">
        <label style="display: inline-block;">Show </label>
        <select style="display: inline-block; width: 75px; cursor: pointer; padding: 8px;" select class="form-control" onchange="location = this.value;">
          <option value="<?php echo e(route($route)); ?>?items=20&page=1" <?php echo e($items == 20 ? 'selected' : ''); ?>>20</option>
          <option value="<?php echo e(route($route)); ?>?items=50&page=1" <?php echo e($items == 50 ? 'selected' : ''); ?>>50</option>
          <option value="<?php echo e(route($route)); ?>?items=100&page=1" <?php echo e($items == 100 ? 'selected' : ''); ?>>100</option>
          <option value="<?php echo e(route($route)); ?>?items=250&page=1" <?php echo e($items == 250 ? 'selected' : ''); ?>>250</option>
          <option value="<?php echo e(route($route)); ?>?items=500&page=1" <?php echo e($items == 250 ? 'selected' : ''); ?>>500</option>
          <option value="<?php echo e(route($route)); ?>?items=1000&page=1" <?php echo e($items == 250 ? 'selected' : ''); ?>>1000</option>
        </select>
        <label style="display: inline-block;"> entries</label>
      </div>

    <?php endif; ?>
  </div>
</div>
<?php /**PATH /home/wwwdemoproje45/public_html/restaurent-billing/resources/views/backend/partials/page_numbering.blade.php ENDPATH**/ ?>