<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
<aside class="app-sidebar of-y-hidden">
  <div data-simplebar class="h-100">

    <?php if(strpos(url('/'), 'localhost') !== false): ?>
        <?php echo $__env->make('backend.pages.root.Importents.developer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    

    <ul class="app-menu admin-menu">

      <?php 
        $role_wise_menus = \App\Models\Role::where('role', Auth()->guard('admin')->user()->admin_role)/*->where('admin_id', Auth()->guard('admin')->user()->id)*/->first();
        /*Getting All Available Menus & Sorting in array*/
        $all_menus = \App\Models\Menu::where('status', 1)->where('parent_id', null)->where('menu_position', 0)->get(['id','order'])->toArray();
        foreach ($all_menus as $key => $all_menu) {
          $_menus[$all_menus[$key]['id']] = $all_menus[$key]['order'];
        }
        asort($_menus);
      ?>
      <?php if($role_wise_menus): ?>
        <?php
        /*decode menus and submenus*/
        $role_menus = json_decode($role_wise_menus->menu);
        $role_sub_menus = json_decode($role_wise_menus->sub_menu);

        /*Escaping from Un-necessary Sidemenus and Sorting*/
        $i = 0;
        foreach ($_menus as $key => $_menu_) {
          $role_menu_temp[$i] = $key;
          $i++;
        }
        foreach ($role_menu_temp as $key => $value) {
          if (!in_array($value, $role_menus)) {
            unset($role_menu_temp[$key]);
          }
        }
        $role_menus = $role_menu_temp;

        ?>

        <?php $__currentLoopData = $role_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <?php
          /*retrieve row for the menu_id*/
          $menu = \App\Models\Menu::roleMenu($role_menu);
          ?>

          
          <?php if(is_null($menu->parent_id) && $menu->menu_position != 2): ?>

            <?php
              $menu_all_submenus = $menu->submenus;
            ?>

            <?php if($menu->route): ?>

              <?php
                if(Route::is($menu->route)){
                  $id = 'me_';
                } else {
                  $id = '';
                }
              ?>
              <li>
                <a id="<?php echo e($id); ?>" class="app-menu__item <?php echo e(Route::is($menu->route) ? 'active' : ''); ?>

                  <?php $__currentLoopData = $menu_all_submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e(Route::is($submenus->route) ? 'active' : ''); ?>

                  <?php $__currentLoopData = $submenus->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in_body): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e(Route::is($in_body->route) ? 'active' : ''); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  " href="<?php echo e(route($menu->route)); ?>" style="position: relative;"><i class="app-menu__icon <?php echo e($menu->icon); ?>"></i><span class="app-menu__label">  <?php if(Config::get('app.locale') == 'en'): ?> <?php echo e($menu->menu); ?> <?php else: ?> <?php echo e($menu->menu_bn); ?> <?php endif; ?> </span>
                  <span class="hover-animation"></span>
                </a>
              </li>
            <?php else: ?>
              <li class="treeview
                <?php $__currentLoopData = $menu_all_submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e(Route::is($submenus->route) ? 'is-expanded' : (strpos(Request::fullUrl(), $submenus->url) !== false ? 'is-expanded' : '')); ?>

                  <?php $__currentLoopData = $submenus->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in_body): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e(Route::is($in_body->route) ? 'is-expanded' : ''); ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> ">

                <a class="app-menu__item
                  <?php $__currentLoopData = $menu_all_submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e(Route::is($submenus->route) ? 'app-menu__item_2' : ''); ?>

                    <?php $__currentLoopData = $submenus->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in_body): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e(Route::is($in_body->route) ? 'app-menu__item_2' : ''); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                " href="#" data-toggle="treeview"
                  <?php $__currentLoopData = $menu_all_submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e(Route::is($submenus->route) ? 'active' : ''); ?>

                    <?php $__currentLoopData = $submenus->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in_body): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e(Route::is($in_body->route) ? 'active' : ''); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> style="position: relative;">
                  <i class="app-menu__icon <?php echo e($menu->icon); ?>"></i>
                  <span class="app-menu__label"><?php if(Config::get('app.locale') == 'en'): ?> <?php echo e($menu->menu); ?> <?php else: ?> <?php echo e($menu->menu_bn); ?> <?php endif; ?></span>
                  <i class="treeview-indicator fa fa-angle-right"></i> 
                  <span class="hover-animation"></span>
                </a>
                <ul class="treeview-menu">
                  <?php $__currentLoopData = $menu_all_submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(\App\Models\Menu::existForRole($submenu->id, $role_sub_menus)): ?>

                  <?php
                  if(Route::is($submenu->route)){ 
                    $id = 'me_';
                  }else{
                    $id = '';
                    foreach($submenu->submenus as $in_body){
                      if(Route::is($in_body->route)){ 
                        $id = 'me_';
                        break;
                      }else{
                        $id = '';
                      }
                    }
                  }
                  ?>

                  <li><a id="<?php echo e($id); ?>" class="treeview-item <?php echo e(Route::is($submenu->route) ? 'active_submenu' : (strpos($submenu->url, 'add') !== false ? (strpos(Request::fullUrl(), $submenu->url) !== false ? 'active_submenu' : $submenu->url) : '')); ?>

                    <?php $__currentLoopData = $submenu->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in_body): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e(Route::is($in_body->route) ? 'active_submenu' : ''); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>" href="<?php echo e(route($submenu->route)); ?>" style="position: relative;"><i class="icon <?php echo e($submenu->icon); ?>"></i> <?php if(Config::get('app.locale') == 'en'): ?> <?php echo e($submenu->menu); ?> <?php else: ?> <?php echo e($submenu->menu_bn); ?> <?php endif; ?>
                    <span class="hover-animation"></span>

                  </a>
                  </li>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </li>
            <?php endif; ?>

          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
    </ul>
  </div>
</aside><?php /**PATH /home/wwwrupkatharesta/public_html/check/resources/views/backend/partials/sidebar.blade.php ENDPATH**/ ?>