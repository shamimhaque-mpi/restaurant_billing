<!-- Full Structure -->


<?php $__env->startSection('fav_title', __('backend/product.view_product') ); ?>

<!-- Write Styles <style>In Here</style> -->
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>

<!-- This Section Will Shown <body>In Here</body> -->
<?php $__env->startSection('content'); ?>
<!-- Top Management Part -->
<div class="app-title">
	<div>
		<h1><i class="<?php echo e('fa fa-archive'); ?>"></i> <?php echo e(__('backend/product.product_management')); ?></h1>
	</div>
	<ul class="app-breadcrumb breadcrumb">
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('backend/default.dashboard')); ?></a></li>
		<?php if('view' == 'index'): ?>
		<li class="breadcrumb-item active"><?php echo e(__('backend/product.product')); ?></li>
		<?php elseif('view' == 'add'): ?>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.product.index')); ?>"><?php echo e(__('backend/product.product')); ?></a></li>
		<li class="breadcrumb-item active"><?php echo e(__('backend/default.add_new')); ?></li>
		<?php elseif('view' == 'edit'): ?>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.product.index')); ?>"><?php echo e(__('backend/product.product')); ?></a></li>
		<li class="breadcrumb-item active"><?php echo e(__('backend/default.edit')); ?></li>
		<?php elseif('view' == 'view'): ?>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.product.index')); ?>"><?php echo e(__('backend/product.product')); ?></a></li>
		<li class="breadcrumb-item active"><?php echo e(__('backend/default.view')); ?></li>
		<?php endif; ?>
	</ul>
</div>

<!-- Table Part -->
<div class="row">
	<div class="col-md-12">
		<div class="card">

			<div class="card-header">
				<div class="row">
					<?php if('view' == 'index'): ?>
					<div class="col-md-6"><h2><i class="<?php echo e('fa fa-eye'); ?>"></i> <?php echo e(__('backend/product.product_list')); ?></h2></div>
					<div class="col-md-6"><a href="<?php echo e(route('admin.product.create')); ?>" class="float-right btn btn-primary"><i class="fa fa-plus"></i> <?php echo e(__('backend/default.add_new')); ?></a></div>

					<?php elseif('view' == 'add'): ?>
					<div class="col-md-6"><h2><i class="<?php echo e('fa fa-eye'); ?>"></i> <?php echo e(__('backend/product.add_product')); ?></h2></div>
					<div class="col-md-6"><a href="<?php echo e(route('admin.product.index')); ?>" class="float-right btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/default.list')); ?></a></div>

					<?php elseif('view' == 'edit'): ?>
					<div class="col-md-6"><h2><i class="<?php echo e('fa fa-eye'); ?>"></i> <?php echo e(__('backend/product.edit_product')); ?></h2></div>
					<div class="col-md-6"><a href="<?php echo e(route('admin.product.index')); ?>" class="float-right btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/default.list')); ?></a></div>

					<?php elseif('view' == 'view'): ?>
					<div class="col-md-6"><h2><i class="<?php echo e('fa fa-eye'); ?>"></i> <?php echo e(__('backend/product.view_product')); ?></h2></div>
					<div class="col-md-6">
						<div class="btn-group float-right">
							<a href="<?php echo e(route('admin.product.index')); ?>" class="btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/default.list')); ?></a><a href="<?php echo e(route('admin.product.edit',$row->slug)); ?>" class="btn btn-warning"><i class="fa fa-edit"></i> <?php echo e(__('backend/default.edit')); ?></a>
						</div>
					</div>
					<?php endif; ?>
					<div class="clearfix"></div>
				</div>
			</div>

			<div class="card-body">

				<div class="col-sm-12">
					<div class="table-responsive">
						<table class="table table-bordered display table-striped">
							<tbody>
								<tr>
									<td>
										<strong>Title: </strong>
									</td>
									<td>
										<span class="monospace-inconsolata"><?php echo e($row->title); ?></span>
									</td>
								</tr>
								<tr>
									<td>
										<strong>Photo: </strong>
									</td>
									<td>
										<img class="monospace-inconsolata" style="width: 200px;" src="<?php echo e(asset($row->image)); ?>">
									</td>
								</tr>
								<tr>
									<td>
										<strong>Category: </strong>
									</td>
									<td>
										<span class="monospace-inconsolata"><?php echo e($row->category->title); ?></span>
									</td>
								</tr>
								<tr>
									<td>
										<strong>Details: </strong>
									</td>
									<td>
										<span class="monospace-inconsolata"><?php echo $row->description; ?></span>
									</td>
								</tr>
								<tr>
									<td>
										<strong>Purchase Price: </strong>
									</td>
									<td>
										<span class="monospace-inconsolata"><?php echo e($row->purchase_price); ?></span>
									</td>
								</tr>
								<tr>
									<td>
										<strong>Sale Price: </strong>
									</td>
									<td>
										<span class="monospace-inconsolata"><?php echo e($row->regular_sale_price); ?></span>
									</td>
								</tr>
								<tr>
									<td>
										<strong>Discount: </strong>
									</td>
									<td>
										<span class="monospace-inconsolata"><?php echo e($row->discount); ?></span>
									</td>
								</tr>
								<tr>
									<td>
										<strong>Total Sale: </strong>
									</td>
									<td>
										<span class="monospace-inconsolata"><?php echo e($row->total_sale); ?></span>
									</td>
								</tr>
								<tr style="background-color: lightcyan;">
									<td>
										<strong>Created: </strong>
									</td>
									<td>
										<span class="monospace-inconsolata"><?php echo e(date_format($row->created_at,"d/M/Y H:i:sa")); ?></span>
									</td>
								</tr>
								<tr style="background-color: lightgoldenrodyellow;">
									<td>
										<strong>Updated: </strong>
									</td>
									<td>
										<span class="monospace-inconsolata"><?php echo e(date_format($row->updated_at,"d/M/Y H:i:sa")); ?></span>
									</td>
								</tr>
								<tr>
									<td>
										<strong>Status: </strong>
									</td>
									<td>
										<span class="monospace-inconsolata"><?php echo e($row->status == 1 ? 'Active' : 'Deactive'); ?></span>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php $__env->stopSection(); ?>

	<!-- Write Scripts <script fileType="text/javascript">In Here</script> -->
	<?php $__env->startSection('scripts'); ?>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wwwdemoproje45/public_html/restaurent-billing/resources/views/backend/pages/product/view.blade.php ENDPATH**/ ?>