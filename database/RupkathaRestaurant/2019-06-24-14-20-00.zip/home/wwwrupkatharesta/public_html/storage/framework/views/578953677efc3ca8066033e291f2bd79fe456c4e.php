<?php $__env->startSection('fav_title', __('backend/menu.menu_list') ); ?>

<?php $__env->startSection('styles'); ?>
<style>
  .action{
    min-width: 70px;
  }
  .table th, .table td{
    vertical-align: middle;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
  <div>
    <h1><i class="fa fa-laptop"></i> <?php echo e(__('backend/menu.menu_management')); ?></h1>
  </div>
  <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-code-fork fa-lg fa-fw"></i> <?php echo e(__('backend/all.developer')); ?></li>
    <li class="breadcrumb-item active"><?php echo e(__('backend/menu.menu')); ?></li>
  </ul>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <div class="row">
          <div class="col-md-6"><h2><i class="fa fa-table"></i> <?php echo e(__('backend/menu.menu')); ?></h2></div>
          <div class="col-md-6">
            <a href="<?php echo e(route('admin.menu.create')); ?>" class="float-right btn btn-primary"><i class="fa fa-plus"></i> <?php echo e(__('backend/default.add_new')); ?></a>
            <a href="<?php echo e(route('admin.role.assign', 'super-admin')); ?>" style="color: white;" class="float-right btn btn-basic Menu_Permission mr-2" title="Super Admin Permission"><i class="fa fa-cogs"></i>/ <i class="fa fa-gavel"></i>/ <i class="fa fa-pencil"></i></a>
          </div>
          <div class="clearfix"></div>
        </div>
      </div>

      <div class="card-body">
        <div class="toggle-table-column">
          <strong><?php echo e(__('backend/default.table_toggle_message')); ?> </strong>
          <a href="#" class="toggle-vis" data-column="0"><b>SL</b></a> | 
          <a href="#" class="toggle-vis" data-column="1"><b>Menu(En)</b></a> | 
          <a href="#" class="toggle-vis" data-column="2"><b>Menu(Bn)</b></a> | 
          <a href="#" class="toggle-vis" data-column="3"><b>Parent</b></a> | 
          <a href="#" class="toggle-vis" data-column="4"><b>Position</b></a> | 
          <a href="#" class="toggle-vis" data-column="5"><b>Icon</b></a> | 
          <a href="#" class="toggle-vis" data-column="6"><b>URL</b></a> |
          <a href="#" class="toggle-vis" data-column="7"><b>Route</b></a> |
          <a href="#" class="toggle-vis" data-column="8"><b>Status</b></a> |
          <a href="#" class="toggle-vis" data-column="9"><b>Action</b></a>
        </div>
        
        <div class="table-responsive">
          <table id="datatable" class="table table-bordered table-hover display">
            <thead>
              <th>SL</th>
              <th>Menu(En)</th>
              <th>Menu(Bn)</th>
              <th>Parent</th>
              <th>Position</th>
              <th>Icon</th>
              <th>URL</th>
              <th>Route</th>
              <th>Status</th>
              <th class="action">Action</th>
            </thead>

            <tbody>
              <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="<?php echo e($menu->status == 0 ? 'deactive_':''); ?>">
                <td><?php echo e($loop->index + 1); ?></td>
                <td><?php echo e($menu->menu); ?></td>
                <td><?php echo e($menu->menu_bn); ?></td>
                <td><?php echo e($menu->parent_id ? $menu->parent->menu : 'N/A'); ?></td>
                <td><?php echo e($menu->menu_position == 0 ? 'Sidebar' : ($menu->menu_position == 1 ? 'In Body' : 'N/A')); ?></td>
                <td><h4><i class="<?php echo e($menu->icon); ?>"></i></h4></td>
                <td><?php echo e($menu->url); ?></td>
                <td><?php echo e($menu->route); ?></td>
                <td><?php echo e($menu->status == 1 ? 'Active' : 'Deactive'); ?></td>
                <td class="action">
                  <div class="btn-group">
                    <a href="<?php echo e(route('admin.menu.edit', $menu->id)); ?>" class="btn btn-info"><i class="fa fa-edit"></i></a>
                    <button class="btn btn-danger" onClick="deleteMethod(<?php echo e($menu->id); ?>)" role="button"><i class="fa fa-trash"></i></button>
                  </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\restaurent-bill\resources\views/backend/pages/menu/index.blade.php ENDPATH**/ ?>