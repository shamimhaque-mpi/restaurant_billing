<?php $__env->startSection('fav_title', 'Sale'); ?>

<?php $__env->startSection('styles'); ?>
<style>
	@media  print{
		.none{
			display: none;
		}
		.hide{
			display: block !important;
		}
		.text-white{
			color: #000000 !important;
		}
	}
	.hide{
		display: none;
	}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
	<div>
		<h1><i class="<?php echo e('fa fa-money'); ?>"></i> <?php echo e(__('backend/sale.sale_management')); ?></h1>
	</div>
	<ul class="app-breadcrumb breadcrumb">
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('backend/default.dashboard')); ?></a></li>
		<?php if('view' == 'index'): ?>
		<li class="breadcrumb-item active"><?php echo e(__('backend/sale.sale')); ?></li>
		<?php elseif('view' == 'add'): ?>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.sale.index')); ?>"><?php echo e(__('backend/sale.sale')); ?></a></li>
		<li class="breadcrumb-item active"><?php echo e(__('backend/default.add_new')); ?></li>
		<?php elseif('view' == 'edit'): ?>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.sale.index')); ?>"><?php echo e(__('backend/sale.sale')); ?></a></li>
		<li class="breadcrumb-item active"><?php echo e(__('backend/default.edit')); ?></li>
		<?php elseif('view' == 'view'): ?>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.sale.index')); ?>"><?php echo e(__('backend/sale.sale')); ?></a></li>
		<li class="breadcrumb-item active"><?php echo e(__('backend/default.view')); ?></li>
		<?php endif; ?>
	</ul>
</div>


<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header">
				<div class="row none">
					<div class="col-md-6"><h2><i class="<?php echo e('fa fa-eye'); ?>"></i> <?php echo e(__('backend/sale.view_sale')); ?></h2></div>
					<div class="col-md-6">
						<a href="<?php echo e(route('admin.sale.index')); ?>" class="float-right btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/default.list')); ?></a>
						<button class="btn btn-info float-right mr-2" onclick="window.print()"><i class="fa fa-fw fa-print"></i><?php echo e(__('backend/default.print')); ?></button>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>

			<div class="card-body">
				<div class="row">
					<?php
					$sale_id = $sales[0]->sale_id;
					$sale_id_len = strlen((string)$sales[0]->sale_id);
					$voucher = $sales[0]->sale_id;
					if($sale_id_len < 2){
						$voucher = "00000".$sale_id;
					}
					elseif($sale_id_len < 3){
						$voucher = "0000".$sale_id;
					}
					elseif($sale_id_len < 4){
						$voucher = "000".$sale_id;
					}
					elseif($sale_id_len < 5){
						$voucher = "00".$sale_id;
					}
					elseif($sale_id_len < 2){
						$voucher = "0".$sale_id;
					}

					$site_setting = \App\Models\Setting::first();
					?>

					<div class="col-sm-12 mb-3 hide" style="border-bottom: 2px solid #009688;">
						<div class="row">
							<div class="col-sm-4 text-left">
								<p class="mt-3"><i class="fa fa-envelope"></i>
									: <?php echo e($site_setting->email); ?><br><i class="fa fa-phone-square"></i>
									: <?php echo e($site_setting->mobile); ?><br><i class="fa fa-facebook-square"></i> : <?php echo e($site_setting->facebook); ?></p>
								</div>
								<div class="col-sm-4 text-center">
									<h4><?php echo e($site_setting->title); ?></h4>
									<span><?php echo $site_setting->address; ?></span>
								</div>
								<div class="col-sm-4">
									<img class=" mt-3" src="<?php echo e(asset('public/images/settings/'.$site_setting->logo)); ?>" style="height: 30px; float: right;">
								</div>
							</div>
						</div>
						<div class="col-sm-12 v_customer">

							<div class="row text-left">
								<div class="col-md-4 ">
									<label class="mx-1"><strong><?php echo e(__('backend/default.voucher')); ?>:</strong> <span class=""><?php echo e($voucher); ?></span> </label>
								</div>
								<div class="col-md-4 ">
									<label class="mx-1"><strong><?php echo e(__('backend/default.customer_name')); ?>:</strong> <?php echo e($sales[0]->customer_name); ?> </label><br>
								</div>
								<div class="col-md-4 ">
									<label class="mx-1"><strong><?php echo e(__('backend/default.customer_mobile')); ?>:</strong> <?php echo e($sales[0]->customer_mobile); ?></label> 
								</div>
								<div class="col-md-4 ">
									<label class="mx-1"><strong><?php echo e(__('backend/default.salesman')); ?>:</strong> <?php echo e($sales[0]->name); ?></label>
								</div>
								<div class="col-md-4 ">
									<label class="vol-sm-12 mb-0"><strong><?php echo e(__('backend/default.date')); ?></strong> : <?php echo e(date('Y-M-d')); ?></label><br>
								</div>
								<div class="col-md-4 ">
									<label class="vol-sm-12 mb-0"><strong><?php echo e(__('backend/default.time')); ?></strong> : <?php echo e(date('h:i:s a')); ?></label>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<div class="table-responsive">
								<table class="table table-bordered display table-striped">
									<thead>
										<th width="5%"><?php echo e(__('backend/default.sl')); ?></th>
										<th><?php echo e(__('backend/product.product')); ?></th>
										<th><?php echo e(__('backend/default.total')); ?></th>
									</thead>
									<tbody>
										<?php
										$totalPrice = 0;
										$totalQty = 0;
										?>
										<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($loop->index + 1); ?></td>
											<td>
												<?php echo e($sale->title); ?> <br>
												(<?php echo e($sale->quantity.' * '.$sale->price); ?>)
												<?php $totalQty += $sale->quantity ?>
												<?php $totalPrice += $sale->price * $sale->quantity ?>
											</td>
											<td><?php echo e($sale->price * $sale->quantity.' ৳'); ?></td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<th colspan="2" class="text-right"><strong><?php echo e(__('backend/default.total')); ?></strong></th>
											<th><?php echo e($totalPrice.' ৳'); ?></th>
										</tr>
										<tr>
											<th colspan="2" class="text-right"><strong><?php echo e(__('backend/default.discount')); ?></strong></th>
											<th><?php echo e($sale->discount.' %'); ?></th>
										</tr>
										<tr>
											<th colspan="2" class="text-right"><strong><?php echo e(__('backend/default.vat')); ?></strong></th>
											<th><?php echo e($sale->vat.' %'); ?></th>
										</tr>
										<tr>
											<th colspan="2" class="text-right"><strong><?php echo e(__('backend/default.payable')); ?></strong></th>
											<th><?php echo e($sale->after_discount.' ৳'); ?></th>
										</tr>
										<tr>
											<th colspan="2" class="text-right"><?php echo e(__('backend/default.paid')); ?></th>
											<th><?php echo e($sales[0]->given_money.' ৳'); ?></th>
										</tr>
										<tr>
											<th colspan="2" class="text-right"><?php echo e(__('backend/default.return')); ?></th>
											<th><?php echo e($sales[0]->given_money - $sale->after_discount.' ৳'); ?></th>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\rupkatharestaurant\resources\views/backend/pages/sale/view.blade.php ENDPATH**/ ?>