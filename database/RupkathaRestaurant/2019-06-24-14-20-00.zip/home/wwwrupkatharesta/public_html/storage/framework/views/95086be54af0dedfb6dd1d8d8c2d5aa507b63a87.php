

<?php $__env->startSection('fav_title', __('backend/default.change_password') ); ?>

<?php $__env->startSection('styles'); ?>
<style type="text/css">
  #eye{
    right: 0;
    bottom: 0;
    font-size: 20px;
    height: 36px;
    color: #009688;
  }
  #eye:hover,
  #eye:focus{
    -webkit-box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.4) !important;
    box-shadow: 0 0 8px 0 rgba(0, 0, 0, 0.4) !important;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
  <div>
    <h1><i class="fa fa-key"></i> <?php echo e(__('backend/admin_setting.change_password')); ?></h1>
  </div>
  <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg fa-fw"></i><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('backend/default.dashboard')); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e(__('backend/admin_setting.admin_setting')); ?></li>
    <li class="breadcrumb-item active"><?php echo e(__('backend/admin_setting.change_password')); ?></li>
  </ul>
</div>

<div class="main-body">
  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
    <div class="card mb-3 col-md-6 offset-md-3">
      <div class="card-body">
        <?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo route('admin.password.change'); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="old_password"><?php echo e(__('backend/default.old') .' '. __('backend/default.password')); ?> <span class="text-danger required">*</span></label>
            <input type="password" class="form-control" name="old_password" id="old_password" value="" placeholder="<?php echo e(__('backend/default.old') .' '. __('backend/default.password')); ?>" required>
            <?php if($errors->has('old_password')): ?>
            <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('old_password')); ?></strong>
            </span>
            <?php endif; ?>
          </div>

          <div class="form-group">
            <label for="password"><?php echo e(__('backend/default.new') .' '. __('backend/default.password')); ?> <span class="text-danger required">*</span></label>
            <input type="password" class="form-control" name="password" id="password" value="" placeholder="<?php echo e(__('backend/default.new') .' '. __('backend/default.password')); ?>" required>
            <?php if($errors->has('password')): ?>
            <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
            <?php endif; ?>
          </div>

          <div class="form-group position-relative">
            <label for="password_confirmation"><?php echo e(__('backend/default.confirm') .' '. __('backend/default.password')); ?> <span class="text-danger required">*</span></label>
            <input type="password" class="form-control" name="password_confirmation" id="password_confirmation" value="" placeholder="<?php echo e(__('backend/default.confirm') .' '. __('backend/default.new') .' '. __('backend/default.password')); ?>" required>
            <span id="eye" class="fa fa-eye btn btn-xs py-0 position-absolute"></span>
            <?php if($errors->has('password_confirmation')): ?>
            <span class="invalid-feedback" role="alert">
              <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
            </span>
            <?php endif; ?>
          </div>

          <button type="submit" class="btn btn-success float-right mt-2"><i class="fa fa-fw fa-sign-in"></i><?php echo e(__('backend/default.submit')); ?></button>
        </form>
      </div><!-- end card-->
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
  $(document).ready(function(){
    $('#eye').click(function(){
      if ($(this).hasClass('fa-eye')) {
        $('#password_confirmation').attr('type', 'text'); 
        $('.fa-eye').addClass('fa-eye-slash');
        $('.fa-eye-slash').removeClass('fa-eye');
      }else if ($(this).hasClass('fa-eye-slash')) {
        $('#password_confirmation').attr('type', 'password'); 
        $('.fa-eye-slash').addClass('fa-eye');
        $('.fa-eye').removeClass('fa-eye-slash');
      }
    }); 
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wwwdemoproje45/public_html/restaurent-billing/resources/views/backend/pages/changePasswordForm.blade.php ENDPATH**/ ?>