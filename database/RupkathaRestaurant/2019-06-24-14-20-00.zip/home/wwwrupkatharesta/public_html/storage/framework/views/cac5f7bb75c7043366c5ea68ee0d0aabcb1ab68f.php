<?php if(Session::has('old_password')): ?>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="alert alert-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <?php echo Session::get('old_password'); ?>

            </div>
        </div>
    </div>
<?php endif; ?>


<?php if($errors->any()): ?>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="alert alert-danger">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php endif; ?><?php /**PATH E:\xampp\htdocs\rupkatharestaurant\resources\views/backend/partials/error_message.blade.php ENDPATH**/ ?>