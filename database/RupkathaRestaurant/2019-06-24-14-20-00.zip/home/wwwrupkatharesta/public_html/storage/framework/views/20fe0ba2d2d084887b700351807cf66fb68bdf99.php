<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <?php
    $site_setting = \App\Models\Setting::first();
  ?>
  <title><?php echo e(ucwords($site_setting->title)); ?> - <?php echo $__env->yieldContent('fav_title'); ?></title>
  
  

  <link rel="icon" href="<?php echo asset('public/images/settings/'.$site_setting->favicon); ?>" type="image/gif" sizes="16x16"> 


  <?php echo $__env->make('backend.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <style>
    .preloader {
     position: absolute;
     top: 0;
     left: 0;
     width: 100%;
     height: 100%;
     z-index: 9999;
     background-image: "<?php echo e(asset('public/5.gif')); ?>";
     background-repeat: no-repeat; 
     background-color: #FFF;
     background-position: center;
   }
   [v-cloak] .v-cloak--block {
    display: block;
  }
  [v-cloak] .v-cloak--inline {
    display: inline;
  }
  [v-cloak] .v-cloak--inlineBlock {
    display: inline-block;
  }
  [v-cloak] .v-cloak--hidden {
    display: none;
  }
  [v-cloak] .v-cloak--invisible {
    visibility: hidden;
  }
  .v-cloak--block,
  .v-cloak--inline,
  .v-cloak--inlineBlock {
    display: none;
  }
  i.fa.fa-spinner.fa-pulse.fa-3x.fa-fw {
    margin-left: 46%;
    bottom: 50%;
    margin-top: 11%;
  }
  .toast-top-right {
    top: 50px !important;
    right: 31px !important;
  }
</style>

<?php $__env->startSection('styles'); ?>
<?php echo $__env->yieldSection(); ?>

</head>
<body class="app sidebar-mini rtl">
<script type="text/javascript">
  <?php if(Route::is('admin.sale.add')): ?>
    $('body').addClass('sidenav-toggled');
  <?php endif; ?>
</script>

  

  <?php echo $__env->make('backend.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('backend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div id="main-wrapper">

    <?php echo $__env->make('backend.partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="app-content" id="app">
      <div v-cloak>
        <div class="v-cloak--inline">
          <i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
          <span class="sr-only">Loading...</span>
        </div>

        <div class="v-cloak--hidden"> 
          <?php $__env->startSection('content'); ?>
          <?php echo $__env->yieldSection(); ?>  
        </div>
      </div>
    </main>

  </div>

  <?php echo $__env->make('backend.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php $__env->startSection('scripts'); ?>
  <?php echo $__env->yieldSection(); ?>

  
</body>
</html><?php /**PATH /home/wwwdemoproje45/public_html/restaurent-billing/resources/views/backend/layouts/master.blade.php ENDPATH**/ ?>