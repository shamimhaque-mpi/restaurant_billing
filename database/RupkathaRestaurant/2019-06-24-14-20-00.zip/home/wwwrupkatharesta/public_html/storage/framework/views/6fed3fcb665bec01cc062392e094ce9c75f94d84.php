<div class="row">
  <?php if($total>0): ?>
  <div class="col-sm-12 col-md-6 pull-right">
    <label  style="float: left"><?php echo e('Showing '.($PreviousPageLastSN+1).' to '); ?> <?php echo e(($PreviousPageLastSN+$items) >= $total ? $total : $PreviousPageLastSN+$items); ?><?php echo e(' of '.$total.' entries'); ?></label>
  </div>
  <?php else: ?>
  <div class="col-sm-12 col-md-12 pull-right">
    <h3 class="alert alert-warning text-center" style="float: left; color: red; width: 100%;"><?php echo e(__('backend/default.no_data')); ?></h3>
  </div>
  <?php endif; ?>

  <div class="col-sm-12 col-md-6 pull-left">
    <?php if(isset($where)): ?>
      <label style="float: right"><?php echo e($table->appends(\Request::query())->render()); ?></label>
    <?php else: ?>
       <label style="float: right"><?php echo e($table->appends(['items' => $items])->links()); ?></label>
    <?php endif; ?>
    
  </div>
</div>
<?php /**PATH E:\xampp\htdocs\rupkatharestaurant\resources\views/backend/partials/pagination.blade.php ENDPATH**/ ?>