

<?php $__env->startSection('fav_title', 'Edit Category'); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
  <div>
    <h1><i class="fa fa-pie-chart"></i> <?php echo e(__('backend/category.category_management')); ?></h1>
  </div>
  <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg fa-fw"></i><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('backend/default.dashboard')); ?></a></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.category.index')); ?>"><?php echo e(__('backend/category.category')); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e(__('backend/default.edit')); ?></li>
  </ul>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <div class="row">
          <div class="col-md-6"><h2><i class="fa fa-pencil-square"></i> <?php echo e(__('backend/category.edit_category')); ?></h2></div>
          <div class="col-md-6"><a href="<?php echo e(route('admin.category.index')); ?>" class="float-right btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/default.list')); ?></a></div>
          <div class="clearfix"></div>
        </div>
      </div>

      <div class="card-body">
        <?php echo $__env->make('backend.partials.error_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <form class="form-horizontal" id="myform" action="<?php echo e(route('admin.category.update', $categories->slug)); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>

          <input type="hidden" name="id" value="<?php echo e($categories->id); ?>">

          <div class="form-group row">
            <label class="control-label col-md-3 text-right">
              <strong><?php echo e(__('backend/form_field.name')); ?></strong> 
            </label>
            <div class="col-md-5">
              <input id="title" class="form-control" type="text" value="<?php echo e($categories->title); ?>" name="title"  required>
            </div>
          </div>

          <?php if($categories->image != NULL): ?>
            <div class="offset-3 col-md-6">
                <img width="200px" height="200px" src="<?php echo e(asset($categories->image)); ?>" alt="">
            </div>
           <?php endif; ?>

          <div class="form-group row mt-3">
            <label class="control-label col-md-3 text-right"><?php echo e(__('backend/form_field.photo')); ?> </label>
            <div class="col-md-5">
              <input id="image" class="form-control" type="file" name="image">
              <input  class="form-control" type="hidden" name="old_image" value="<?php echo e($categories->image); ?>" >
            </div>
          </div>

          <div class="form-group row">
            <label class="control-label col-md-3 text-right">
              <strong><?php echo e(__('backend/form_field.status')); ?></strong> 
            </label>
            <div class="col-md-5">
              <select id="status" class="form-control"  name="status">
                <option value="1" <?php echo e($categories->status == 1 ? 'selected' : ''); ?>>Active</option>
                <option value="0" <?php echo e($categories->status == 0 ? 'selected' : ''); ?>>Deactive</option>
              </select>
            </div>
          </div>
          
          <input type="hidden" name="url" value="<?php echo e(url('/')); ?>">        
          <div class="form-row">
            <div class="col-md-8 mt-3">
              <button type="submit" name="save" class="btn btn-success float-right"><?php echo e(__('backend/default.submit')); ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wwwdemoproje45/public_html/restaurent-billing/resources/views/backend/pages/category/edit.blade.php ENDPATH**/ ?>