<!-- Full Structure -->


<?php $__env->startSection('fav_title', 'Add'); ?>

<!-- Write Styles <style>In Here</style> -->
<?php $__env->startSection('styles'); ?>
<style type="text/css">
	.container__ {
		height: 140px;
	}

	.inner {
		height: 140px;
		white-space:nowrap;
	}

	.floatLeft {
		cursor: pointer;
		width: 100px;
		height: 100px; 
		margin:10px 10px 10px 10px; 
		display: inline-block;
	}
	img {
		height: 100%;
	}
	input[type='number'] {
		-moz-appearance:textfield;
	}

	input::-webkit-outer-spin-button,
	input::-webkit-inner-spin-button {
		-webkit-appearance: none;
	}
</style>
<?php $__env->stopSection(); ?>

<!-- This Section Will Shown <body>In Here</body> -->
<?php $__env->startSection('content'); ?>
<!-- Top Management Part -->
<div class="app-title">
	<div>
		<h1><i class="<?php echo e('fa fa-money'); ?>"></i> <?php echo e(__('backend/sale.sale_management')); ?></h1>
	</div>
	<ul class="app-breadcrumb breadcrumb">
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('backend/default.dashboard')); ?></a></li>
		<?php if('add' == 'index'): ?>
		<li class="breadcrumb-item active"><?php echo e(__('backend/sale.sale')); ?></li>
		<?php elseif('add' == 'add'): ?>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.sale.index')); ?>"><?php echo e(__('backend/sale.sale')); ?></a></li>
		<li class="breadcrumb-item active"><?php echo e(__('backend/default.add_new')); ?></li>
		<?php elseif('add' == 'edit'): ?>
		<li class="breadcrumb-item"><a href="<?php echo e(route('admin.sale.index')); ?>"><?php echo e(__('backend/sale.sale')); ?></a></li>
		<li class="breadcrumb-item active"><?php echo e(__('backend/default.edit')); ?></li>
		<?php endif; ?>
	</ul>
</div>

<!-- Add Form Part -->
<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header">
				<div class="row">
					<?php if('add' == 'index'): ?>
					<div class="col-md-6"><a href="<?php echo e(route('admin.sale.add')); ?>" class="float-right btn btn-primary"><i class="fa fa-plus"></i> <?php echo e(__('backend/default.add_new')); ?></a></div>

					<?php elseif('add' == 'add'): ?>
					<div class="col-md-6"><h2><i class="<?php echo e('fa fa-plus-square'); ?>"></i> <?php echo e(__('backend/sale.add_sale')); ?></h2></div>
					<div class="col-md-6"><a href="<?php echo e(route('admin.sale.index')); ?>" class="float-right btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/default.list')); ?></a></div>

					<?php elseif('add' == 'edit'): ?>
					<div class="col-md-6"><h2><i class="<?php echo e('fa fa-plus-square'); ?>"></i> <?php echo e(__('backend/sale.edit_sale')); ?></h2></div>
					<div class="col-md-6"><a href="<?php echo e(route('admin.sale.index')); ?>" class="float-right btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/default.list')); ?></a></div>
					<?php endif; ?>
					<div class="clearfix"></div>
				</div>
			</div>
			<div class="card-body">
				<add-sale 
				submit="<?php echo e(__('backend/default.submit')); ?>" 
				product="<?php echo e(__('backend/product.product')); ?>" 
				:categories="<?php echo e($categories); ?>" 
				select_category="<?php echo e(__('backend/form_field.select_category')); ?>"
				url="<?php echo e(url('/')); ?>"
				bill="<?php echo e(__('backend/default.go_to_bill')); ?>"
				sl="<?php echo e(__('backend/default.sl')); ?>"
				photo="<?php echo e(__('backend/form_field.photo')); ?>"
				name="<?php echo e(__('backend/form_field.name')); ?>"
				quantity="<?php echo e(__('backend/default.quantity')); ?>"
				price="<?php echo e(__('backend/default.price')); ?>"
				discount="<?php echo e(__('backend/default.discount')); ?>"
				vat="<?php echo e(__('backend/default.vat')); ?>"
				total="<?php echo e(__('backend/default.total')); ?>"
				customer_name_field="<?php echo e(__('backend/default.customer_name')); ?>"
				paid_field="<?php echo e(__('backend/default.paid')); ?>"
				customer_mobile_field="<?php echo e(__('backend/default.customer_mobile')); ?>"
				no_data="<?php echo e(__('backend/default.no_data')); ?>"
				action="<?php echo e(__('backend/default.action')); ?>"
				url="<?php echo e(url('/')); ?>"
				after_discount="<?php echo e(__('backend/default.after_discount')); ?>"
				return_field="<?php echo e(__('backend/default.return')); ?>"
				payable_field="<?php echo e(__('backend/default.payable')); ?>"
				>
			</add-sale>
		</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>

	$(document).ready(function(){
		$('.floatLeft').click(function() {
			$(this).siblings().removeClass('border-active');
			$(this).addClass('border-active');
		});
	});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\rupkatharestaurant\resources\views/backend/pages/sale/add.blade.php ENDPATH**/ ?>