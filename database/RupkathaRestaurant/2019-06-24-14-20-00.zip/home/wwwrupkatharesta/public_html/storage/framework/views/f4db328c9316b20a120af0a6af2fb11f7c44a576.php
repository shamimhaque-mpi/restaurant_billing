<?php $__env->startSection('fav_title', __('backend/default.dashboard') ); ?>

<?php $__env->startSection('content'); ?>

<div class="app-title">
    <div>
        <h1><i class="fa fa-dashboard"></i> <?php echo e(__('backend/default.dashboard')); ?></h1>
    </div>
    <ul class="app-breadcrumb breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i> <?php echo e(__('backend/default.dashboard')); ?></li>
    </ul>
</div>


<div class="row">
    
    <div class="col-md-6 col-lg-3">
        <div class="widget-small primary coloured-icon"><i class="icon fa fa-money fa-3x"></i>
            <div class="info">
                <h4><?php echo e(__('backend/sale.sale')); ?></h4>
                <p><b><?php echo e(sprintf('%0.2f', $today_sale)); ?> ৳</b></p>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="widget-small danger coloured-icon"><i class="icon fa fa-money fa-3x"></i>
            <div class="info">
                <h4><?php echo e(__('backend/default.purchase')); ?></h4>
                <p><b><?php echo e(sprintf('%0.2f', $today_purchase_cost)); ?> ৳</b></p>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="widget-small warning coloured-icon"><i class="icon fa fa-money fa-3x"></i>
            <div class="info">
                <h4><?php echo e(__('backend/cost.cost')); ?></h4>
                <p><b><?php echo e(sprintf('%0.2f', $today_other_cost)); ?> ৳</b></p>
            </div>
        </div>
    </div>
    <div class="col-md-6 col-lg-3">
        <div class="widget-small info coloured-icon"><i class="icon fa fa-money fa-3x"></i>
            <div class="info">
                <h4><?php echo e(__('backend/balance_sheet.balance')); ?></h4>
                <p><b><?php echo e(sprintf('%0.2f', $today_sale - ($today_purchase_cost + $today_other_cost))); ?> ৳</b></p>
            </div>
        </div>
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\rupkatharestaurant\resources\views/backend/pages/index.blade.php ENDPATH**/ ?>