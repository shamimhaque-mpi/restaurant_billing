<?php if(Session::has('add_message')): ?>
  <script>
    toastr.success("<?php echo e(__('backend/flash.add_message')); ?>");
  </script>
<?php endif; ?>

<?php if(Session::has('update_message')): ?>
  <script>
    toastr.success("<?php echo e(__('backend/flash.update_message')); ?>");
  </script>
<?php endif; ?>

<?php if(Session::has('warning')): ?>
  <script>
    toastr.warning("<?php echo e(Session::get('warning')); ?>");
  </script>
<?php endif; ?>

<?php if(Session::has('delete_message')): ?>
  <script>
    toastr.error("<?php echo e(__('backend/flash.delete_message')); ?>");
  </script>
<?php endif; ?>

<?php if(Session::has('deactive_message')): ?>
  <script>
    toastr.error("<?php echo e(__('backend/flash.deactive_message')); ?>");
  </script>
<?php endif; ?>


<?php /**PATH /home/wwwdemoproje45/public_html/restaurent-billing/resources/views/backend/partials/message.blade.php ENDPATH**/ ?>