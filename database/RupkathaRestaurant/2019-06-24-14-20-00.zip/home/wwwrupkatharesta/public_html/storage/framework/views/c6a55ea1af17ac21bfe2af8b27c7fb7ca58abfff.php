<?php $__env->startSection('fav_title', 'Sort Menu'); ?>

<?php $__env->startSection('styles'); ?>
<style type="text/css">
  table .form-control,
  table .form-control:active,
  table .form-control:hover,
  table .form-control:focus {
    border: none !important;
  }
  tbody.listitems td:last-child {
    padding: 0 !important;
  }
  table {
    border-collapse: inherit;
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
  <div>
    <h1><i class="fa fa-laptop"></i> <?php echo e(__('backend/menu.menu_management')); ?></h1>
  </div>
  <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-code-fork fa-lg fa-fw"></i> <?php echo e(__('backend/all.developer')); ?></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.menu.index')); ?>"><?php echo e(__('backend/menu.menu')); ?></a></li>
    <li class="breadcrumb-item active"><?php echo e(__('backend/default.edit')); ?></li>
  </ul>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="card">
      <div class="card-header">
        <div class="row">
          <div class="col-md-6"><h2><i class="fa fa-table"></i> <?php echo e(__('backend/menu.menu_sort')); ?></h2></div>
          <div class="col-md-6"><a href="<?php echo e(route('admin.menu.index')); ?>" class="float-right btn btn-primary"><i class="fa fa-arrow-left"></i> <?php echo e(__('backend/menu.menu_list')); ?></a></div>
          <div class="clearfix"></div>
        </div>
      </div>

      <div class="card-body">
        <?php echo $__env->make('backend.partials.error_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('admin.menu.sort_update')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="row">
            <div class="col-md-7 mx-auto">
                <table class="table table-bordered br-4">
                  <thead>
                    <tr class="alert-secondary">
                      <th for="SL" class="">SL </th>
                      <th for="menu" class="w-75">Name </th>
                      <th for="order" class="">Order </th>
                    </tr>
                  </thead>
                  <tbody class="listitems autosort">
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr data-position="<?php echo e($menu->order); ?>">
                      <td class="cursor-default" id="index"></td>
                      <td class="cursor-default"><?php echo e($menu->menu); ?></td>
                      <td style="background-image: linear-gradient(#eee, #fff, #fff, #eee);">
                        <input type="hidden" class="form-control avro_bn" name="id[]" id="id" value="<?php echo e($menu->id); ?>" required>
                        <input type="text" class="form-control avro_bn" name="order[]" id="order" value="<?php echo e($menu->order); ?>" required style="background: transparent;">
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <button type="submit" name="save_menu" class="btn btn-success float-right"><?php echo e(__('backend/default.submit')); ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
  $(document).ready(function(){
    $('#parent_id').select2();
    $(".listitems").each(function(){
      $(this).html($(this).children('tr').sort(function(a, b){
        return ($(b).data('position')) < ($(a).data('position')) ? 1 : -1;
      }));
    });
    var ind = 0;
    $('tbody #index').each(function() {
      ind = ind +1;
      $(this).prepend("<span>" + ind + "</span>");
    });
  });
  
  $(function(){
    $('input[name=menu_bn]').avro({'bangla':true}, 
      /*function(isBangla){
      alert('Bangla enabled = ' + isBangla);
    }*/
    );
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\rupkatharestaurant\resources\views/backend/pages/menu/sort.blade.php ENDPATH**/ ?>