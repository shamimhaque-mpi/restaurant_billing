<?php echo e($slot); ?>

<?php /**PATH /home/wwwdemoproje45/public_html/restaurent-billing/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>