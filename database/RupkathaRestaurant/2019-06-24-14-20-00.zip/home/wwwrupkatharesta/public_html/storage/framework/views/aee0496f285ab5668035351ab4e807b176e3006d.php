<!-- Full Structure -->


<?php $__env->startSection('fav_title', __('backend/balance_sheet.balance_sheet') ); ?>

<!-- Write Styles <style>In Here</style> -->
<?php $__env->startSection('styles'); ?>

<style type="text/css">
	.datepicker {
		margin-top: 60px;
	}
	.input-group-addon i {
		height: 33px !important;
		right: 2px;
		top: 2px;
	}
</style>
<?php $__env->stopSection(); ?>

<!-- This Section Will Shown <body>In Here</body> -->
<?php $__env->startSection('content'); ?>


<div class="card">
	<div class="card-header">
		<div class="row">
			<div class="col-md-12">
				<h2><i class="fa fa-table"></i> <?php echo e(__('backend/balance_sheet.balance_sheet')); ?></h2>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
	<div class="card-body">
		<form action="<?php echo e(route('admin.balance_sheet.index')); ?>" method="post">
			<?php echo csrf_field(); ?>
			<div class="row mb-3">
				<div class="col-md-3">
					<div class="input-group date" id="fromDate" data-provide="datepicker">
						<input type="text" class="form-control from_date" name="from_date" value="<?php echo e($app->request->input('from_date')); ?>" autocomplete="off">
						<div class="input-group-addon from_icon">
							<span><i class="fa fa-calendar"></i></span>
						</div>
					</div>
				</div>
				<div class="col-md-3">
					<div class="input-group date" id="toDate" data-provide="datepicker">
						<input type="text" class="form-control to_date" name="to_date" value="<?php echo e($app->request->input('to_date')); ?>" autocomplete="off">
						<div class="input-group-addon to_icon">
							<span><i class="fa fa-calendar"></i></span>
						</div>
					</div>
				</div>
				<div class="col-md-1">
					<button class="btn btn-primary searchByDate" type="submit"><?php echo e(__('backend/default.search')); ?></button>
				</div>
			</div>
		</form>

		<br>



		<div class="row">							
			<div class="col-md-6">
				<div class="card">
					<div class="card-header">
						<div class="row">
							<div class="col-md-12"><h2><i class="fa fa-table"></i> <?php echo e(__('backend/balance_sheet.sales')); ?></h2></div><div class="clearfix"></div>
						</div>
					</div>

					<div class="card-body">        
						<div class="table-responsive">
							<table class="table table-bordered table-hover display">
								<thead>
									<th><?php echo e(__('backend/default.sl')); ?></th>
									
									<th><?php echo e(__('backend/default.voucher')); ?></th>
									<th><?php echo e(__('backend/balance_sheet.amount')); ?></th>
								</thead>
								<tbody>
									<?php
									$totalSale = 0;
									?>	
									<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
									<tr class="">
										<td><?php echo e($loop->index + 1); ?></td>
										
										<td><?php echo e(\App\Helpers\CalculationHelper::generateVoucher($sale->id)); ?></td>
										<td><?php echo e($sale->total_price_after_discount.' ৳'); ?> <?php $totalSale += $sale->total_price_after_discount; ?></td>                  
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
									<tr>
										<td colspan="2" class="text-right"><strong><?php echo e(__('backend/default.total')); ?></strong></td>
										<td><strong><?php echo e($totalSale.' ৳'); ?></strong></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>



			

			<div class="col-md-6">
				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<div class="row">
									<div class="col-md-12"><h2><i class="fa fa-table"></i> <?php echo e(__('backend/balance_sheet.purchases')); ?></h2></div><div class="clearfix"></div>
								</div>
							</div>
							<div class="card-body">        
								<div class="table-responsive">
									<table  class="table table-bordered table-hover display">
										<thead>
											<th><?php echo e(__('backend/default.sl')); ?></th>
											
											<th><?php echo e(__('backend/default.voucher')); ?></th>
											<th><?php echo e(__('backend/balance_sheet.amount')); ?></th>
										</thead>
										<tbody>
											<?php
											$totalPuchase = 0;
											?>	
											<?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr class="">
												<td><?php echo e($loop->index + 1); ?></td>
												
												<td><?php echo e(\App\Helpers\CalculationHelper::generateVoucher($purchase->id)); ?></td>
												<td><?php echo e($purchase->price.' ৳'); ?> <?php $totalPuchase += $purchase->price; ?></td>                  
											</tr>
											<tr>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
												<td colspan="2" class="text-right"><strong><?php echo e(__('backend/default.total')); ?></strong></td>
												<td><strong><?php echo e($totalPuchase.' ৳'); ?></strong></td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>

				<br><br>

				<div class="row">
					<div class="col-md-12">
						<div class="card">
							<div class="card-header">
								<div class="row">
									<div class="col-md-12"><h2><i class="fa fa-table"></i> <?php echo e(__('backend/cost.cost')); ?></h2></div><div class="clearfix"></div>
								</div>
							</div>
							<div class="card-body">        
								<div class="table-responsive">
									<table  class="table table-bordered table-hover display">
										<thead>
											<th><?php echo e(__('backend/default.sl')); ?></th>
											
											<th><?php echo e(__('backend/default.voucher')); ?></th>
											<th><?php echo e(__('backend/balance_sheet.amount')); ?></th>
										</thead>
										<tbody>
											<?php
											$totalCost = 0;
											?>
											<?php $__currentLoopData = $costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr class="">
												<td><?php echo e($loop->index + 1); ?></td>
												
												<td><?php echo e(\App\Helpers\CalculationHelper::generateVoucher($cost->id)); ?></td>
												<td><?php echo e($cost->price.' ৳'); ?> <?php $totalCost += $cost->price; ?></td>                  
											</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td colspan="2" class="text-right"><strong><?php echo e(__('backend/default.total')); ?></strong></td>
												<td><strong><?php echo e($totalCost.' ৳'); ?></strong></td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<br><br>
		<?php
		$balance = $totalSale - ($totalPuchase+$totalCost)
		?>
		<div class="row <?php echo e($balance > 0 ? 'alert-success' : 'alert-danger'); ?> pt-2">
			<div class="col-md-12 text-center"><strong><h3>Total : <?php echo e($balance); ?> </h3></strong></div>
		</div>	
	</div>
</div>
<?php $__env->stopSection(); ?>

<!-- Write Scripts <script fileType="text/javascript">In Here</script> -->
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">

	$(document).ready(function(){
		$('#fromDate').datepicker({
			format: 'yyyy-mm-dd',
			todayHighlight:'TRUE',
			autoclose: true,
		});

		$('#toDate').datepicker({
			format: 'yyyy-mm-dd',
			todayHighlight:'TRUE',
			autoclose: true,
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wwwdemoproje45/public_html/restaurent-billing/resources/views/backend/pages/balance_sheet/index.blade.php ENDPATH**/ ?>