
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `admin_access_infos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_access_infos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_access_infos` WRITE;
/*!40000 ALTER TABLE `admin_access_infos` DISABLE KEYS */;
INSERT INTO `admin_access_infos` VALUES (1,1,'::1',NULL,'PC','Chrome',1,'2019-04-15 02:39:07','2019-04-15 02:39:07'),(2,1,'::1',NULL,'PC','Firefox',1,'2019-04-15 02:59:01','2019-04-15 02:59:01'),(3,1,'::1',NULL,'PC','Firefox',1,'2019-04-15 21:18:25','2019-04-15 21:18:25'),(4,1,'::1',NULL,'PC','Firefox',1,'2019-04-16 05:13:57','2019-04-16 05:13:57'),(5,1,'::1',NULL,'PC','Chrome',1,'2019-04-16 21:29:30','2019-04-16 21:29:30'),(6,1,'127.0.0.1',NULL,'PC','Firefox',1,'2019-04-17 21:10:33','2019-04-17 21:10:33'),(7,1,'::1',NULL,'PC','Firefox',1,'2019-04-18 02:15:15','2019-04-18 02:15:15'),(8,1,'::1',NULL,'PC','Chrome',1,'2019-04-18 13:54:08','2019-04-18 13:54:08'),(9,1,'::1',NULL,'PC','Chrome',1,'2019-04-18 15:09:37','2019-04-18 15:09:37'),(10,1,'::1',NULL,'PC','Chrome',1,'2019-04-18 15:14:41','2019-04-18 15:14:41'),(11,1,'::1',NULL,'PC','Chrome',1,'2019-04-18 15:17:54','2019-04-18 15:17:54'),(12,1,'::1',NULL,'PC','Chrome',1,'2019-04-18 15:18:35','2019-04-18 15:18:35');
/*!40000 ALTER TABLE `admin_access_infos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_role` tinyint(4) DEFAULT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `admins_email_unique` (`email`) USING BTREE,
  UNIQUE KEY `admins_username_unique` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'Super Admin','super@gmail.com','superadmin',1,NULL,'$2y$10$tQVwD5VequDrZsgg5NUaHexmp3fGf.XI7zylpDEqSxf9WJITYiRWO',1,'3t5kcZ7Y6FcbBHNebQiItGNzFMOtgfqfVHnpjshK9qAsI02ViwhwewBJ3be4','2019-03-24 12:00:00','2019-03-24 12:00:00'),(2,'Admin','admin@gmail.com','admin',2,NULL,'$2y$10$tQVwD5VequDrZsgg5NUaHexmp3fGf.XI7zylpDEqSxf9WJITYiRWO',1,'6vuWhUPgtss78UKu2PjTTId6Y5vS4yj8Vzs6WHwk1PcTKDxV7dqyzOw1MrS3','2019-03-24 12:00:00','2019-04-15 03:51:44');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `sub_category_id` int(10) unsigned DEFAULT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `brands_slug_unique` (`slug`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `categories_slug_unique` (`slug`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'Fast Food','food','public/images/category/1555585027.jpg',1,'2019-04-18 04:57:07','2019-04-18 04:57:41'),(2,'Drinks','drinks','public/images/category/1555585098.jpg',1,'2019-04-18 04:58:18','2019-04-18 04:58:18'),(3,'Deshi Food','deshi-food','public/images/category/1555585138.jpg',1,'2019-04-18 04:58:58','2019-04-18 04:58:58');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `costs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `costs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cost_field` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` double(8,2) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `costs` WRITE;
/*!40000 ALTER TABLE `costs` DISABLE KEYS */;
/*!40000 ALTER TABLE `costs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_bn` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `menu_position` int(10) unsigned DEFAULT NULL COMMENT '0 - Left | 1 - Top | 2 - Dropdown',
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `route` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `menus` WRITE;
/*!40000 ALTER TABLE `menus` DISABLE KEYS */;
INSERT INTO `menus` VALUES (1,'Admin Settings','এডমিন সেটিংস',NULL,0,'fa fa-cogs',NULL,NULL,500,1,'2019-03-25 04:40:17','2019-03-25 04:40:17'),(2,'Change Password','পাসওয়ার্ড পরিবর্তন',1,0,'fa fa-cog','/admin/change-password','admin.password.form',1,1,'2019-03-25 04:42:35','2019-03-25 04:42:35'),(3,'Menu Permission','মেনু পারমিশন',1,0,'fa fa-cogs','/admin/role','admin.role.index',2,1,'2019-03-25 04:44:32','2019-03-25 04:44:32'),(4,'Log Activity','লগ এক্টিভিটি',1,0,'fa fa-cog','/admin/log','admin.log.index',3,1,'2019-03-25 04:46:37','2019-03-25 04:47:03'),(5,'Assign','অনুমতি প্রদান',3,1,'fa fa-pencil','/admin/role/assign','admin.role.assign',1,1,'2019-03-25 04:48:50','2019-03-25 04:48:50'),(6,'Dashboard','ড্যাশবোর্ড',NULL,0,'fa fa-dashboard','/admin','admin.home',1,1,'2019-03-25 05:02:05','2019-03-25 05:02:05'),(33,'Product','পণ্য',NULL,0,'fa fa-archive',NULL,NULL,50,1,'2019-03-29 21:43:47','2019-03-29 22:43:46'),(34,'Product List','পণ্য তালিকা',33,0,'fa fa-list-ul','/admin/product','admin.product.index',1,1,'2019-03-29 21:45:03','2019-03-29 21:45:03'),(35,'Add New','নতুন যোগ করুন',33,0,'fa fa-plus','/admin/product/add','admin.product.create',2,1,'2019-03-29 21:47:44','2019-03-29 21:47:44'),(36,'Edit','এডিট',34,1,'fa fa-pencil',NULL,'admin.product.edit',2,1,'2019-03-29 21:48:20','2019-04-05 23:27:38'),(37,'Delete','ডিলিট',34,1,'fa fa-trash',NULL,'admin.product.delete',3,1,'2019-03-29 21:49:55','2019-04-05 23:27:26'),(38,'Category','ক্যাটাগরি',NULL,0,'fa fa-pie-chart',NULL,NULL,90,1,'2019-03-29 21:51:15','2019-03-30 00:11:55'),(39,'Category List','ক্যাটাগরি তালিকা',38,0,'fa fa-list-ul','/admin/category','admin.category.index',1,1,'2019-03-29 21:51:59','2019-03-29 21:51:59'),(40,'Add New','নতুন যোগ করুন',38,0,'fa fa-plus','/admin/category/add','admin.category.create',2,1,'2019-03-29 21:52:31','2019-03-29 21:52:31'),(41,'Edit','এডিট',39,1,'fa fa-pencil',NULL,'admin.category.edit',1,1,'2019-03-29 21:53:02','2019-03-29 22:55:28'),(42,'Delete','ডিলিট',39,1,'fa fa-trash',NULL,'admin.category.delete',2,1,'2019-03-29 21:53:33','2019-03-29 23:01:25'),(82,'Site Settings','সাইট সেটিংস',NULL,0,'fa fa-sliders','/admin/setting','admin.setting.index',450,1,'2019-04-10 22:30:44','2019-04-11 02:33:10'),(83,'Admin','এডমিন',NULL,0,'fa fa-user-secret',NULL,NULL,501,1,'2019-04-11 02:34:35','2019-04-11 02:34:35'),(84,'Admins','এডমিনগণ',83,0,'fa fa-users','/admin/myAdmin','admin.myadmin.index',1,1,'2019-04-11 02:37:34','2019-04-11 02:38:00'),(85,'Add Admin','এডমিন যোগ করুন',83,0,'fa fa-plus','/admin/myAdmin/add','admin.myadmin.add',2,1,'2019-04-11 02:39:51','2019-04-11 02:39:51'),(86,'Edit','এডিট',84,1,'fa fa-pencil',NULL,'admin.myadmin.edit',1,1,'2019-04-11 02:40:57','2019-04-11 02:42:38'),(87,'Delete','ডিলিট',84,1,'fa fa-trash',NULL,'admin.myadmin.delete',2,1,'2019-04-11 02:42:59','2019-04-11 02:42:59'),(88,'Sale','বিক্রয়',NULL,0,'fa fa-money',NULL,NULL,49,1,'2019-04-15 21:53:59','2019-04-15 21:53:59'),(89,'All Sale','সকল বিক্রয়',88,0,'fa fa-list-ul','/admin/sale','admin.sale.index',1,1,'2019-04-15 22:03:48','2019-04-15 22:03:48'),(90,'New Sale','নতুন বিক্রয়',88,0,'fa fa-plus','/admin/sale/add','admin.sale.add',2,1,'2019-04-15 22:04:42','2019-04-15 22:04:42'),(91,'Edit','ইডিট',89,1,'fa fa-edit',NULL,'admin.sale.edit',2,1,'2019-04-15 22:05:33','2019-04-15 22:05:33'),(92,'Delete','ডিলিট',89,1,'fa fa-trash',NULL,'admin.sale.delete',3,1,'2019-04-15 22:06:43','2019-04-15 22:06:43'),(93,'View','ভিউ',89,1,'fa fa-eye',NULL,'admin.sale.view',1,1,'2019-04-16 04:13:15','2019-04-16 04:13:15'),(94,'Cost','খরচ',NULL,0,'fa fa-contao',NULL,NULL,100,1,'2019-04-17 00:05:39','2019-04-17 00:07:41'),(95,'Cost List','খরচ তালিকা',94,0,'fa fa-list-ul','/admin/cost','admin.cost.index',1,1,'2019-04-17 00:29:35','2019-04-17 00:29:35'),(96,'Add New','নতুন যোগ করুন',94,0,'fa fa-plus','/admin/cost/add','admin.cost.add',2,1,'2019-04-17 00:30:27','2019-04-17 00:30:27'),(97,'Edit','এডিট',95,1,'fa fa-edit',NULL,'admin.cost.edit',1,1,'2019-04-17 00:31:30','2019-04-17 00:31:30'),(98,'Delete','ডিলিট',95,1,'fa fa-trash',NULL,'admin.cost.delete',2,1,'2019-04-17 00:33:15','2019-04-17 00:33:15'),(99,'view','দেখা',34,1,'fa fa-eye',NULL,'admin.product.view',1,1,'2019-04-18 04:15:38','2019-04-18 04:15:38');
/*!40000 ALTER TABLE `menus` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2018_03_26_200821_create_admins_table',1),(2,'2019_03_04_084037_create_menus_table',1),(3,'2019_03_05_074453_create_roles_table',1),(4,'2019_03_06_090310_create_admin_access_infos_table',1),(5,'2019_03_25_140140_create_units_table',1),(6,'2019_03_25_140157_create_categories_table',1),(7,'2019_03_25_140207_create_sub_categories_table',1),(8,'2019_03_25_140231_create_brands_table',1),(9,'2019_03_25_140240_create_password_resets_table',1),(10,'2019_03_25_140240_create_users_table',1),(11,'2019_04_10_152516_create_settings_table',1),(12,'2019_04_15_081819_create_products_table',1),(13,'2019_04_15_082535_create_sales_table',1),(14,'2019_04_15_082553_create_sale_products_table',1),(15,'2019_04_15_083217_create_costs_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(10) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purchase_price` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `regular_sale_price` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_sale` int(10) unsigned DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `products_slug_unique` (`slug`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Mango Juice','mango-juice',2,'Fresh Cold Mango Juice.','public/images/products/1555585321.jpg','70','120','0',0,1,'2019-04-18 05:02:01','2019-04-18 05:02:01'),(2,'Orange Juice','orange-juice',2,'Sweet Orange Juice.','public/images/products/1555585422.jpg','59','106','5',0,1,'2019-04-18 05:03:42','2019-04-18 05:03:42'),(3,'Coca-Cola','coca-cola',2,'Coca-Cola 250ml.','public/images/products/1555585509.jpg','16','25','0',0,1,'2019-04-18 05:05:09','2019-04-18 05:05:09'),(4,'Chicken Fry','chicken-fry',3,'Chicken Chilly Fry','public/images/products/1555585597.jpg','70','180','0',0,1,'2019-04-18 05:06:37','2019-04-18 05:06:37'),(5,'Ilish Rice','ilish-rice',3,'Ilish Panta Rice.','public/images/products/1555585678.jpg','70','310','10',0,1,'2019-04-18 05:07:58','2019-04-18 05:07:58'),(6,'Tomato Curry','tomato-curry',3,'Tomato Chilly Curry.','public/images/products/1555585771.jpg','30','127','9',0,1,'2019-04-18 05:09:31','2019-04-18 05:09:31'),(7,'Burger & French Fry','burger-&-french-fry',1,'Burger & French Fry','public/images/products/1555585894.jpg','165','390','10',0,1,'2019-04-18 05:11:34','2019-04-18 05:11:34'),(8,'Samucha','samucha',1,'Deshi Samucha.','public/images/products/1555585964.jpg','3','15','0',0,1,'2019-04-18 05:12:44','2019-04-18 05:12:44'),(9,'Pizza','pizza',1,'Chicken Pizza.','public/images/products/1555586118.png','202','459','4',0,1,'2019-04-18 05:15:18','2019-04-18 05:15:18');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menu` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_menu` text COLLATE utf8mb4_unicode_ci,
  `in_body` text COLLATE utf8mb4_unicode_ci,
  `role` tinyint(3) unsigned NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'[\"6\",\"88\",\"33\",\"38\",\"94\",\"82\",\"1\",\"83\"]','[\"89\",\"84\",\"90\",\"2\",\"35\",\"95\",\"40\",\"39\",\"96\",\"34\",\"85\",\"4\",\"3\"]','[\"93\",\"86\",\"87\",\"92\",\"97\",\"5\",\"37\",\"42\",\"91\",\"41\",\"36\",\"99\",\"98\"]',1,1,'2019-04-15 03:12:29','2019-04-18 04:15:50');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sale_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sale_products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `quantity` double(8,2) NOT NULL DEFAULT '1.00',
  `price` double(8,2) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sale_products` WRITE;
/*!40000 ALTER TABLE `sale_products` DISABLE KEYS */;
INSERT INTO `sale_products` VALUES (1,1,1,3.00,120.00,1,NULL,NULL),(2,1,2,1.00,100.70,1,NULL,NULL);
/*!40000 ALTER TABLE `sale_products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `admin_id` int(10) unsigned NOT NULL,
  `customer_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_price` double(8,2) NOT NULL,
  `total_product` double(8,2) NOT NULL,
  `given_money` double(8,2) NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,1,NULL,NULL,460.70,4.00,500.00,1,'2019-04-18 14:41:20','2019-04-18 14:41:20');
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `favicon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `facebook` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `twitter` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `youtube` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `linkedin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'logo-1555583380.jpg','favicon-1555584605.jpg','Restaurent Bill','superadmin@Restaurent-Bill.com','01234567890','https://fb.com/ecom','twitter','youtube','linkedin','City: Mymensingh\r\nCountry: Bangladesh\r\nState: Mymensingh Division\r\nZipcode: 2200','1','2019-04-10 12:00:00','2019-04-18 04:50:06');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sub_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `sub_categories_slug_unique` (`slug`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sub_categories` WRITE;
/*!40000 ALTER TABLE `sub_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `sub_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `units` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_role` tinyint(4) DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district_id` int(10) unsigned DEFAULT NULL,
  `upazilla_id` int(10) unsigned DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `users_email_unique` (`email`) USING BTREE,
  UNIQUE KEY `users_mobile_unique` (`mobile`) USING BTREE,
  UNIQUE KEY `users_username_unique` (`username`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

